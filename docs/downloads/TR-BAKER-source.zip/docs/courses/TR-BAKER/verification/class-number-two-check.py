"""Exact finite checks for the class-number-two structural calculations.

These checks verify the eighteen displayed examples and coefficient identities.
They do not assert that a finite search classifies every discriminant.
"""
from pathlib import Path
from math import gcd, isqrt
from collections import Counter
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent


def forms(d):
    answer = []
    for a in range(1, isqrt(d // 3) + 1):
        for b in range(-a, a + 1):
            if (b*b+d) % (4*a):
                continue
            c = (b*b+d)//(4*a)
            if c < a or gcd(gcd(a, b), c) != 1:
                continue
            if b < 0 and (abs(b) == a or a == c):
                continue
            answer.append((a, b, c))
    return answer


def primes(n):
    result = []
    for p in range(2, isqrt(n) + 1):
        if n % p == 0:
            result.append(p)
            while n % p == 0:
                n //= p
    if n > 1:
        result.append(n)
    return result


def legendre(n, p):
    n %= p
    if n == 0:
        return 0
    return 1 if n in {r*r % p for r in range(1, p)} else -1


def odd_character(D, n):
    # For an odd fundamental discriminant, its prime-discriminant
    # characters are the Legendre characters of their conductors.
    value = 1
    for p in primes(abs(D)):
        assert p % 2
        value *= legendre(n, p)
    return value


text = (HERE.parent/'src/TR-BAKER-18.md').read_text(encoding='utf-8')
table = []
for m, d, triples in re.findall(r'^\| (\d+) \| \\\(-(?P<d>\d+)\\\) \| (.*?) \|$', text, re.M):
    m, d = int(m), int(d)
    assert d == (m if m % 4 == 3 else 4*m)
    expected = [tuple(map(int, item)) for item in re.findall(r'\((\d+),(\d+),(\d+)\)', triples)]
    actual = forms(d)
    assert actual == expected and len(actual) == 2, (m, actual, expected)
    assert all(b == 0 or abs(b) == a or a == c for a, b, c in actual)
    table.append({'radicand': m, 'discriminant': -d, 'forms': actual})
assert len(table) == 18

checks = 0
ramified = []
examples = []
limit = 250
for row in table:
    d = -row['discriminant']
    if d % 2 == 0:
        continue
    factors = primes(d)
    assert len(factors) == 2
    p = next(x for x in factors if x % 4 == 1)
    q = next(x for x in factors if x % 4 == 3)
    c = (p+q)//4
    assert gcd(c, d) == 1
    assert legendre(c, p) == legendre(q, p) == legendre(p, q)
    ramified.append([d, p, q, legendre(c, p)])
    representations = Counter()
    # (2x+y)^2+d*y^2=4n bounds y and then x for n<=limit.
    ymax = isqrt(4*limit//d)
    xmax = isqrt(4*limit)+ymax+1
    for y in range(-ymax, ymax+1):
        for x in range(-xmax, xmax+1):
            n = x*x+x*y+(d+1)*y*y//4
            if 1 <= n <= limit:
                representations[n] += 1
    for k in (1, 5, 13, 21, 33, 65):
        if gcd(k, d) != 1:
            continue
        for n in range(1, limit+1):
            first = sum(odd_character(-d, a) for a in range(1, n+1) if n % a == 0)
            second = sum(legendre(a, p)*legendre(n//a, q) for a in range(1, n+1) if n % a == 0)
            weight = odd_character(k, n)
            assert weight*(first+second) == weight*representations[n], (d, k, n)
            checks += 1
    examples.append({'discriminant': -d, 'principal_form_coefficients': dict(sorted(representations.items()))})

receipt = {
    'state': 'passed',
    'scope': '18 displayed form enumerations; odd-case ramified genus signs; exact principal-form coefficient identity through n=250. Not a global class-number-two exclusion.',
    'source_sha256': hashlib.sha256((HERE.parent/'src/TR-BAKER-18.md').read_bytes()).hexdigest(),
    'checker_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'examples': table,
    'ramified_genus_checks': ramified,
    'twisted_coefficient_checks': checks,
    'principal_form_coefficients': examples,
}
(HERE/'class-number-two-check.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8', newline='\n')
print({'state': 'passed', 'displayed_fields': len(table), 'coefficient_checks': checks, 'ramified_checks': len(ramified)})
