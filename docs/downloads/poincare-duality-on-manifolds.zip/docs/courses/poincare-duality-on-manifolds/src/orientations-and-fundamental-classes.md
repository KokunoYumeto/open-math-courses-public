# Orientations and fundamental classes

*Programme text prepared with Claude Opus 5.5 (Anthropic), GPT-6 Astra (OpenAI) and GPT-6.1 Sol (OpenAI). Original programme text: public domain (CC0).*

Near each of its points, an \(n\)-dimensional manifold looks like \(\mathbf R^n\), and the homology of \(\mathbf R^n\) relative to the complement of a point is a single copy of the coefficient ring in degree \(n\). An orientation is a consistent choice of generators of these local groups. This lesson proves the basic structure theorem behind every duality statement on manifolds: for a compact subset \(K\), the homology of the manifold relative to the complement of \(K\) vanishes above degree \(n\), and an orientation determines a unique class in degree \(n\) that restricts to the chosen generator at every point of \(K\). For a closed oriented manifold this is the fundamental class. Along the way we show that a connected manifold is orientable exactly when transporting a local generator around every loop brings it back to itself, that a manifold whose coordinate changes have positive Jacobian determinant is oriented, in particular that every complex manifold carries a canonical orientation, and that products of oriented manifolds are oriented, with the product of the fundamental classes as fundamental class.

We use singular homology as in the core course [Algebraic Topology](https://kokunoyumeto.github.io/program-matematika-indonesia/en/#course-D60), whose homology part follows Y. Fomberg's notes: homotopy invariance [Fomberg, Theorem 1.13 and Corollary 1.14], the long exact sequence of a short exact sequence of chain complexes [Fomberg, Theorem 1.21], excision [Fomberg, Theorems 1.23 and 1.26], small chains [Fomberg, Proposition 1.25], the homology of spheres [Fomberg, Corollary 1.17], the generator of \(H_n(\Delta^n,\partial\Delta^n)\) [Fomberg, Proposition 1.29] and the degree of a reflection [Fomberg, Proposition 1.35(4)]. From [Thom classes and Euler classes](https://github.com/KokunoYumeto/open-math-courses/blob/main/docs/courses/DG-CHAR/thom-classes-and-euler-classes.md#2-making-singular-chains-small) we use Lemma 5.1: every subgroup of a free abelian group is free; and, for products, the shuffle map \(S\), the Alexander–Whitney map \(A\) and Lemma 4.1 of Section 4 there: \(S\) and \(A\) are inverse natural chain homotopy equivalences between \(C_\bullet(X)\otimes C_\bullet(Y)\) and \(C_\bullet(X\times Y)\), their homotopies preserve products of subspaces, and they pass to relative complexes for open subspaces; the external product of cohomology classes is \(a\times b=\operatorname{pr}_1^*a\smile\operatorname{pr}_2^*b\), whose cochain is \(a\otimes b\) evaluated after \(A\).

Basic references are [Hatcher] and [Miller].

## 1. Coefficients and local homology

A **topological manifold** of dimension \(n\) is a Hausdorff, second countable space in which every point has an open neighbourhood homeomorphic to \(\mathbf R^n\). A **chart** is a homeomorphism \(\varphi:U\to\varphi(U)\) from an open subset of \(M\) onto an open subset of \(\mathbf R^n\). For \(A\subset M\) we write \(M\setminus A\) for the complement, and \(M\setminus x\) for \(M\setminus\{x\}\).

**Coefficients.** Let \(R\) be a commutative ring and put \(C_\bullet(X;R)=C_\bullet(X)\otimes R\), where \(C_\bullet(X)\) is the integral singular chain complex. The results of the core course listed above hold with coefficients in \(R\). Complete chain-level proofs of homotopy invariance, small chains, excision and the exact sequences are supplied by [Thom classes and Euler classes, Lemma 1.1, Lemma 2.1, Corollary 2.2 and Section 3](https://github.com/KokunoYumeto/open-math-courses/blob/main/docs/courses/DG-CHAR/thom-classes-and-euler-classes.md#2-making-singular-chains-small). Those proofs produce chain homotopies and degreewise split short exact sequences of free abelian chain complexes; the sequence \(0\to C_\bullet(A)\to C_\bullet(X)\to C_\bullet(X,A)\to0\) of a pair is split in each degree, because \(C_n(X,A)\) is free on the simplices not contained in \(A\). Tensoring with \(R\) preserves chain homotopies and degreewise split short exact sequences, so homotopy invariance, the long exact sequences of pairs and triples, excision, Mayer–Vietoris sequences and the small-chain theorem hold with coefficients in \(R\). All homology groups below have coefficients in \(R\), omitted from the notation when no confusion arises.

**Lemma 1.1.** Let \(K\) be a chain complex of free abelian groups whose homology groups \(H_m(K)\) are all free. Then \(K\) is chain homotopy equivalent to the complex \(H_\bullet(K)\) with zero differential, and for every commutative ring \(R\) the map \(H_m(K)\otimes R\to H_m(K\otimes R)\), \([z]\otimes r\mapsto[z\otimes r]\), is an isomorphism.

**Proof.** Write \(Z_m\) and \(B_m\) for the cycles and boundaries in \(K_m\); they are free by Lemma 5.1 of [Thom classes and Euler classes](https://github.com/KokunoYumeto/open-math-courses/blob/main/docs/courses/DG-CHAR/thom-classes-and-euler-classes.md#2-making-singular-chains-small). The surjection \(\partial:K_m\to B_{m-1}\) onto a free group splits, so \(K_m=Z_m\oplus L_m\) with \(\partial:L_m\to B_{m-1}\) bijective. The surjection \(Z_m\to H_m(K)\) onto a free group splits too, so \(Z_m=B_m\oplus E_m\) with \(E_m\cong H_m(K)\). Hence \(K\) is the direct sum of the complex \(E_\bullet\) with zero differential and the two-term complexes \(P_m=(L_m\xrightarrow{\ \partial\ }B_{m-1})\), each of which is contractible, a contraction being the inverse of \(\partial\). So the projection \(K\to E_\bullet\) is a chain homotopy equivalence. The decomposition survives tensoring with \(R\), each \(P_m\otimes R\) remains contractible, and \(E_m\otimes R\) consists of cycles; therefore every class of \(H_m(K\otimes R)\) is represented by a unique element of \(E_m\otimes R\), which is the stated isomorphism. \(\square\)

**Lemma 1.2 (local homology).** Let \(M\) be an \(n\)-manifold, \(n\geq1\), and let \(K\subset M\) be a compact set contained in the domain \(U\) of a chart \(\varphi\) such that \(\varphi(K)\) is convex.

1. For every \(x\in K\), the restriction \(H_i(M,M\setminus K)\to H_i(M,M\setminus x)\) is an isomorphism, and these groups are free of rank one over \(R\) for \(i=n\) and zero for \(i\neq n\).
2. The image of a generator of the integral group \(H_n(M,M\setminus K;\mathbf Z)\) under the coefficient map \(\mathbf Z\to R\) generates \(H_n(M,M\setminus K;R)\).
3. If \(S\subset\varphi(U)\) is an affine \(n\)-simplex containing \(\varphi(K)\) in its interior and \(\sigma:\Delta^n\to S\) an affine homeomorphism, then the class of the singular simplex \(\varphi^{-1}\circ\sigma\) generates \(H_n(M,M\setminus K;R)\).

**Proof.** For an empty compact set the relative complex is zero. We therefore assume \(K\neq\emptyset\) in the radial argument. *Reduction to \(\mathbf R^n\).* The closed set \(M\setminus U\) lies in the open set \(M\setminus K\), so excision [Fomberg, Theorem 1.23] gives \(H_i(U,U\setminus K)\cong H_i(M,M\setminus K)\). The chart identifies this with \(H_i(V,V\setminus C)\), where \(V=\varphi(U)\) and \(C=\varphi(K)\). The closed set \(\mathbf R^n\setminus V\) lies in the open set \(\mathbf R^n\setminus C\), and excision again gives \(H_i(V,V\setminus C)\cong H_i(\mathbf R^n,\mathbf R^n\setminus C)\). All these identifications are compatible with restriction to a point.

*Radial deformation.* Fix \(p\in C\) and a radius \(r\) with \(C\) contained in the open ball of radius \(r\) about \(p\). For \(y\neq p\) write \(y=p+s u\) with \(|u|=1\), \(s>0\). Because \(C\) is convex and contains \(p\), the set of \(t\geq0\) with \(p+tu\in C\) is an interval \([0,t_0(u)]\), and \(t_0(u)<r\). The homotopy \(h_\lambda(p+su)=p+\bigl((1-\lambda)s+\lambda r\bigr)u\), \(0\leq\lambda\leq1\), moves every point of \(\mathbf R^n\setminus C\) within \(\mathbf R^n\setminus C\) (the new radius exceeds \(t_0(u)\) whenever \(s\) does) and every point of \(\mathbf R^n\setminus p\) within \(\mathbf R^n\setminus p\), and fixes the sphere \(\Sigma\) of radius \(r\) about \(p\). So \(\Sigma\) is a deformation retract of both \(\mathbf R^n\setminus C\) and \(\mathbf R^n\setminus p\), and the inclusion \(\mathbf R^n\setminus C\to\mathbf R^n\setminus p\) is a homotopy equivalence. By homotopy invariance, the long exact sequences of the pairs and the five lemma, \(H_i(\mathbf R^n,\mathbf R^n\setminus C)\to H_i(\mathbf R^n,\mathbf R^n\setminus p)\) is an isomorphism. Since \(\mathbf R^n\) is contractible, the long exact sequence identifies \(H_i(\mathbf R^n,\mathbf R^n\setminus p;\mathbf Z)\) with \(\tilde H_{i-1}(\Sigma;\mathbf Z)\), which is \(\mathbf Z\) for \(i=n\) and zero otherwise [Fomberg, Corollary 1.17]. This proves (1) and (2) with integral coefficients, for every \(p\in C\), hence for every \(x\in K\).

*Arbitrary coefficients.* The relative chain complex \(C_\bullet(\mathbf R^n)/C_\bullet(\mathbf R^n\setminus C)\) is free, with integral homology \(\mathbf Z\) in degree \(n\) and zero elsewhere. Lemma 1.1 gives (1) and (2) for \(R\), compatibly with restriction to points.

*The simplex.* By [Fomberg, Proposition 1.29] the identity simplex generates \(H_n(\Delta^n,\partial\Delta^n;\mathbf Z)\), so \(\sigma\) generates \(H_n(S,\partial S;\mathbf Z)\). Radial deformation from a point \(p\) of \(C\), now towards \(\partial S\), shows as above that \(\partial S\) is a deformation retract of \(S\setminus C\) (each ray from \(p\) leaves the convex set \(C\) once and meets \(\partial S\) once), so \(H_n(S,\partial S)\to H_n(S,S\setminus C)\) is an isomorphism. The closed set \(\mathbf R^n\setminus\operatorname{int}S\) lies in \(\mathbf R^n\setminus C\), so excision gives \(H_n(S,S\setminus C)\cong H_n(\mathbf R^n,\mathbf R^n\setminus C)\). Hence \([\sigma]\) generates \(H_n(\mathbf R^n,\mathbf R^n\setminus C;\mathbf Z)\), and by (2) its image generates the group with coefficients in \(R\); under the identifications of the first paragraph it is the class of \(\varphi^{-1}\circ\sigma\). \(\square\)

**Zero-dimensional local groups.** A zero-dimensional manifold is discrete. Each singular simplex is constant because its domain is connected. Consequently its chain complex is the direct sum, over its points, of point complexes. For compact \(K\), the relative complex for \((M,M\setminus K)\) is the direct sum of the point complexes indexed by the finite set \(K\); its homology is \(\bigoplus_{x\in K}R\) in degree zero and zero in every other degree. Restriction to a point picks the corresponding coordinate. A nonempty convex chart set in dimension zero is a singleton, and its unique singular zero-simplex is the integral generator, whose image generates with coefficients in \(R\). Thus all conclusions of Lemma 1.2 also hold in dimension zero. For \(K=\emptyset\) every relative group is zero.

## 2. Orientations

**Definition 2.1.** An **\(R\)-orientation** of \(M\) is a function \(x\mapsto\mu_x\) assigning to each \(x\in M\) a generator \(\mu_x\) of the free rank-one \(R\)-module \(H_n(M,M\setminus x)\), which is **locally consistent**: every point has a compact neighbourhood \(D\) and a class \(\mu_D\in H_n(M,M\setminus D)\) whose image in \(H_n(M,M\setminus y)\) is \(\mu_y\) for every \(y\in D\). The manifold is **\(R\)-orientable** if such a function exists; a \(\mathbf Z\)-orientation is simply called an orientation. A function with the same consistency property whose values need not be generators is called a **locally consistent family**.

Restricting \(\mu_D\) shows that every smaller compact neighbourhood of the point serves as well.

**Lemma 2.2.** Let \(x\mapsto\mu_x\) be a locally consistent family, and let \(K\subset M\) be compact, contained in a chart domain with convex image. There is a unique class \(\mu_K\in H_n(M,M\setminus K)\) whose image in \(H_n(M,M\setminus x)\) is \(\mu_x\) for every \(x\in K\).

**Proof.** For \(K=\emptyset\), the unique class is zero in the zero relative group. Suppose \(K\neq\emptyset\). By Lemma 1.2(1), for each \(x\in K\) there is a unique \(\kappa_x\in H_n(M,M\setminus K)\) restricting to \(\mu_x\); we show that \(\kappa_x\) does not depend on \(x\). Let \(y\in K\), let \(D\) be a compact neighbourhood of \(y\) as in Definition 2.1, and let \(D'\subset D\) be the preimage of a closed ball about \(\varphi(y)\) in the chart of \(K\), small enough to lie in \(D\). Then \(C=K\cap D'\) is compact with convex image and contains \(y\), and the restriction of \(\mu_D\) to \(C\) restricts to \(\mu_z\) at every \(z\in C\). For \(z\in C\), both \(\kappa_z\) and \(\mu_D\) restrict on \(C\) to classes with image \(\mu_z\) at \(z\); by Lemma 1.2(1) for \(C\), these restrictions are equal, and since restriction from \(K\) to \(C\) is an isomorphism (both groups are isomorphic to the group at \(z\)), \(\kappa_z\) is determined by the restriction of \(\mu_D\) to \(C\). So \(z\mapsto\kappa_z\) is constant near \(y\). Since the convex set \(\varphi(K)\) is connected, \(\kappa_x\) is the same for all \(x\in K\). \(\square\)

**Proposition 2.3.**

1. On a connected manifold, two locally consistent families that agree at one point agree everywhere; in particular two \(R\)-orientations agreeing at one point are equal.
2. Every manifold is \(\mathbf Z/2\)-orientable.
3. An orientation \(\mu\) induces an \(R\)-orientation for every \(R\), namely the images of the \(\mu_x\) under the coefficient map \(\mathbf Z\to R\).
4. A connected orientable manifold has exactly two orientations, \(\mu\) and \(-\mu\).
5. An \(R\)-orientation of \(M\) induces one of every open subset \(W\), through the excision isomorphisms \(H_n(W,W\setminus x)\cong H_n(M,M\setminus x)\).

**Proof.** (1) Let \(\mu,\mu'\) be the families and \(y\) a point. Choose compact neighbourhoods as in Definition 2.1 for both families and, inside their intersection, a compact neighbourhood \(C\) of \(y\) contained in a chart domain with convex image. By Lemma 2.2 there are unique classes \(\mu_C,\mu'_C\) restricting to the two families on \(C\), and by Lemma 1.2(1) each is determined by its value at \(y\). If \(\mu_y=\mu'_y\), then \(\mu_C=\mu'_C\) and the families agree on \(C\); if \(\mu_y\neq\mu'_y\), they disagree at every point of \(C\). So the sets where they agree and where they differ are open, and the first is nonempty, hence everything.

(2) For a closed chart ball \(D\) about \(y\) (the preimage of a closed ball), \(H_n(M,M\setminus D;\mathbf Z/2)\cong\mathbf Z/2\) restricts isomorphically to each point of \(D\) by Lemma 1.2(1), so the nonzero elements form a locally consistent family of generators.

(3) The coefficient map commutes with restriction, so local consistency is preserved, and by Lemma 1.2(2) generators go to generators.

(4) The group \(H_n(M,M\setminus x;\mathbf Z)\cong\mathbf Z\) has two generators. The family \(-\mu\) is an orientation, and every orientation agrees at \(x\) with \(\mu\) or with \(-\mu\), hence everywhere by (1).

(5) Excision [Fomberg, Theorem 1.23] identifies \(H_n(W,W\setminus A)\) with \(H_n(M,M\setminus A)\) for compact \(A\subset W\), compatibly with restriction. Compact neighbourhoods in \(M\) of a point of \(W\) can be shrunk into \(W\). \(\square\)

**Transport along paths.** Call a compact set \(D\subset M\) a **convex chart set** if it lies in the domain of a chart \(\varphi\) with \(\varphi(D)\) convex; a closed chart ball, the preimage of a closed ball, is one. For such \(D\) and \(y\in D\), the restriction \(r^D_y:H_n(M,M\setminus D)\to H_n(M,M\setminus y)\) is an isomorphism by Lemma 1.2(1). For a path \(\gamma:[a,b]\to M\) with image in the interior of a convex chart set \(D\), put

\[
\begin{aligned}
&T^D_\gamma\\
&\quad =r^D_{\gamma(b)}\circ\bigl(r^D_{\gamma(a)}\bigr)^{-1}:H_n(M,M\setminus\gamma(a))\\
&\quad \longrightarrow H_n(M,M\setminus\gamma(b)).
\end{aligned}
\]

Two rules follow from the definition. (a) If \(D'\subset D\) are convex chart sets and \(\gamma([a,b])\subset\operatorname{int}D'\), then \(T^{D'}_\gamma=T^D_\gamma\), because \(r^D_y\) is \(r^{D'}_y\) composed with the restriction from \(D\) to \(D'\). (b) If \(a<c<b\), then \(T^D_{\gamma|[a,b]}=T^D_{\gamma|[c,b]}\circ T^D_{\gamma|[a,c]}\), since \(r^D_{\gamma(c)}\) and its inverse cancel.

**Lemma 2.4 (transport).** Let \(\gamma:[0,1]\to M\) be a path. There are \(0=s_0<s_1<\cdots<s_k=1\) and convex chart sets \(D_1,\ldots,D_k\) with \(\gamma([s_{j-1},s_j])\subset\operatorname{int}D_j\), and the isomorphism

\[
\begin{aligned}
&T_\gamma=T^{D_k}_{\gamma|[s_{k-1},s_k]}\circ\cdots\circ T^{D_1}_{\gamma|[s_0,s_1]}:\\
&\quad H_n(M,M\setminus\gamma(0))\\
&\qquad\longrightarrow H_n(M,M\setminus\gamma(1))
\end{aligned}
\]

does not depend on these choices. It satisfies \(T_{\gamma\cdot\delta}=T_\delta\circ T_\gamma\) for paths with \(\gamma(1)=\delta(0)\), and \(T_{\bar\gamma}=T_\gamma^{-1}\) for the reversed path \(\bar\gamma(s)=\gamma(1-s)\). Every locally consistent family satisfies \(T_\gamma(\mu_{\gamma(0)})=\mu_{\gamma(1)}\).

**Proof.** *Existence.* Every point \(\gamma(s)\) lies in the interior of a closed chart ball. The preimages under \(\gamma\) of these interiors cover \([0,1]\), and a Lebesgue number gives the subdivision.

*Independence.* By (b), adding a subdivision point, with the same set on the two new intervals, does not change the composite. Given two choices, pass to the union of their subdivision points. Each interval \([c,e]\) of the common subdivision lies in an interval of each choice, with sets \(D\) and \(D'\), so \(\gamma([c,e])\subset\operatorname{int}D\cap\operatorname{int}D'\). Every point of the compact set \(\gamma([c,e])\) is the centre of a closed ball, for the chart of \(D\), contained in \(\operatorname{int}D\cap\operatorname{int}D'\); a Lebesgue number gives a subdivision of \([c,e]\) whose pieces each map into the interior of one such ball \(B\). On each piece, (a) gives \(T^D=T^B=T^{D'}\), and by (b) the two composites over \([c,e]\) agree.

*The rest.* Concatenating subdivisions gives \(T_{\gamma\cdot\delta}=T_\delta\circ T_\gamma\), and running the same choices backwards gives \(T_{\bar\gamma}=T_\gamma^{-1}\). If \(\mu\) is locally consistent, Lemma 2.2 gives classes \(\mu_{D_j}\) with image \(\mu_y\) at every \(y\in D_j\), so the \(j\)-th factor sends \(\mu_{\gamma(s_{j-1})}\) to \(\mu_{\gamma(s_j)}\). \(\square\)

**Proposition 2.5 (loop criterion).** Let \(M\) be connected and \(x\in M\). Then \(M\) is \(R\)-orientable if and only if \(H_n(M,M\setminus x)\) has a generator \(\mu_x\) with \(T_\gamma(\mu_x)=\mu_x\) for every loop \(\gamma\) at \(x\). In particular \(M\) is orientable if and only if \(T_\gamma\) is the identity of \(H_n(M,M\setminus x;\mathbf Z)\) for every loop \(\gamma\) at \(x\): transported around any loop, a local generator returns to itself.

**Proof.** If \(\mu\) is an \(R\)-orientation, Lemma 2.4 gives \(T_\gamma(\mu_x)=\mu_x\). Conversely, a connected manifold is path connected, since its path components are open (chart balls are path connected). For \(y\in M\) choose a path \(\gamma\) from \(x\) to \(y\) and put \(\mu_y=T_\gamma(\mu_x)\), a generator. A second path \(\gamma'\) gives the same class, because \(T_{\gamma'}^{-1}T_\gamma=T_{\gamma\cdot\bar\gamma'}\) fixes \(\mu_x\). For local consistency at \(y\), choose closed chart balls \(D\subset\operatorname{int}D'\) for one chart, with \(y\) in the interior of \(D\), and let \(\mu_{D'}\in H_n(M,M\setminus D')\) be the class with image \(\mu_y\) at \(y\) (Lemma 1.2(1)). For \(z\in D\), the segment \(\sigma\) from \(y\) to \(z\) in the chart lies in \(\operatorname{int}D'\), so \(\mu_z=T_{\gamma\cdot\sigma}(\mu_x)=T^{D'}_\sigma(\mu_y)\) is the image of \(\mu_{D'}\) at \(z\). The image \(\mu_D\) of \(\mu_{D'}\) in \(H_n(M,M\setminus D)\) therefore has image \(\mu_z\) at every \(z\in D\).

For \(R=\mathbf Z\), \(T_\gamma\) is an automorphism of \(\mathbf Z\), so it is the identity as soon as it fixes one generator. \(\square\)

## 3. Orientations from charts

**The zero-dimensional standard orientation.** Let \(\tau_0\) be the singular zero-simplex at the point of \(\mathbf R^0\), and let \(o_0=[\tau_0]=1\) in \(H_0(\mathbf R^0;\mathbf Z)\). This defines the standard orientation in dimension zero. The empty matrix has determinant one, and the unique map from the point to itself induces the identity on this group.

**The standard orientation of \(\mathbf R^m\).** Let \(m\geq1\), let \(e_1,\ldots,e_m\) be the standard basis, and let \(\tau_m\) be the affine simplex with vertices \(w_0,w_0+e_1,\ldots,w_0+e_m\), where \(w_0=-(e_1+\cdots+e_m)/(m+1)\); its barycentre is \(0\). By Lemma 1.2(3), its class \(o_m\in H_m(\mathbf R^m,\mathbf R^m\setminus0;\mathbf Z)\) is a generator. For a closed ball \(D\) about \(0\), let \(o_D\in H_m(\mathbf R^m,\mathbf R^m\setminus D;\mathbf Z)\) be the class restricting to \(o_m\) at \(0\) (Lemma 1.2(1)), and for \(z\in\mathbf R^m\) let \(\mu^{\rm std}_z\) be the image of \(o_D\) at \(z\), for any closed ball \(D\) about \(0\) containing \(z\). For balls \(D\subset D'\), the class \(o_{D'}\) restricts to \(o_D\), since both restrict to \(o_m\) at \(0\); so \(\mu^{\rm std}_z\) is well defined. It is a generator, and the classes \(o_D\) for balls containing a point in their interior show local consistency. This orientation \(\mu^{\rm std}\) is the **standard orientation** of \(\mathbf R^m\); on an open subset of \(\mathbf R^m\) we use the induced orientation of Proposition 2.3(5).

**Lemma 3.1.** Translations and invertible linear maps with positive determinant preserve the standard orientation: for \(v\in\mathbf R^m\), the translation \(T_v(x)=x+v\) maps \(\mu^{\rm std}_z\) to \(\mu^{\rm std}_{z+v}\), and for \(A\in GL_m(\mathbf R)\) with \(\det A>0\), \(A_*\mu^{\rm std}_0=\mu^{\rm std}_0\).

**Proof.** In dimension zero both a translation and an invertible linear map are the identity of the point, and hence preserve \(o_0\). For positive dimension we argue as follows. *Linear maps.* The group \(GL^+_m(\mathbf R)\) of matrices with positive determinant is path connected. Indeed, row operations adding a multiple of one row to another (left multiplication by a matrix \(I+cE_{ij}\), \(i\neq j\)) reduce every invertible matrix to the diagonal matrix \(\operatorname{diag}(1,\ldots,1,\det A)\): first make the \((1,1)\) entry equal to \(1\) (if the first column has a nonzero entry below the diagonal, add a suitable multiple of that row to the first row; otherwise first add the first row to a row below), then clear the rest of the first column and, by column operations of the same kind, the rest of the first row, and continue with the lower right block. Each matrix \(I+cE_{ij}\) is joined to \(I\) by the path \(I+tcE_{ij}\) in \(GL^+_m(\mathbf R)\), and \(\operatorname{diag}(1,\ldots,1,d)\), \(d>0\), by \(\operatorname{diag}(1,\ldots,1,1-t+td)\). Products of paths give a path from \(I\) to \(A\). A path \(A_t\) from \(I\) to \(A\) in \(GL_m(\mathbf R)\) is a homotopy of maps of pairs \((\mathbf R^m,\mathbf R^m\setminus0)\to(\mathbf R^m,\mathbf R^m\setminus0)\), so \(A_*=I_*\) on \(H_m(\mathbf R^m,\mathbf R^m\setminus0)\).

*Translations.* Let \(D\) be the closed ball of radius \(\rho\) about \(0\) and \(D'\) the closed ball of radius \(\rho+|v|\). For \(0\leq t\leq1\), \(T_{tv}\) maps \(\mathbf R^m\setminus D'\) into \(\mathbf R^m\setminus D\), so \((T_{tv})\) is a homotopy of maps of pairs \((\mathbf R^m,\mathbf R^m\setminus D')\to(\mathbf R^m,\mathbf R^m\setminus D)\) from the identity to \(T_v\). Hence \((T_v)_*o_{D'}=o_D\). Restrict to a point \(z\) of the interior of \(D'\) with \(z+v\) in \(D\): naturality of restriction gives \((T_v)_*\mu^{\rm std}_z=\mu^{\rm std}_{z+v}\). Every \(z\) is such a point once \(\rho\) is large. \(\square\)

**Proposition 3.2 (local degree).** Let \(W\subset\mathbf R^m\) be open, \(f:W\to\mathbf R^m\) continuous, and \(p\in W\) a point at which \(f\) is differentiable with invertible derivative \(A=Df(p)\); put \(q=f(p)\). Then \(f(x)\neq q\) for all \(x\neq p\) in a small open ball \(B\) about \(p\), and the induced map \(f_*:H_m(B,B\setminus p)\to H_m(\mathbf R^m,\mathbf R^m\setminus q)\) sends \(\mu^{\rm std}_p\) to \(\mu^{\rm std}_q\) if \(\det A>0\).

**Proof.** If \(m=0\), then \(W=\mathbf R^0=\{p\}\), \(q\) is the sole point of the target and \(B=\{p\}\). There are no other points to exclude. The map on local \(H_0\) sends the singular point class to the singular point class, so it preserves the standard generator; the determinant of the empty derivative matrix is one. Now assume \(m\geq1\). Put \(c=\min_{|u|=1}|Au|>0\) and
\[
\eta(s)=\sup_{0<|h|\leq s}\frac{|f(p+h)-q-Ah|}{|h|},
\]
which tends to \(0\) as \(s\to0\) by differentiability. Choose \(\varepsilon>0\) such that \(\eta(\varepsilon)<c\) and the closed ball of radius \(\varepsilon\) about \(p\) lies in \(W\), and let \(B\) be the open ball of radius \(\varepsilon\) about \(p\). For \(x\in B\) and \(0<t\leq1\) define
\[
\begin{gathered}
F_t(x)=q+\frac{f\bigl(p+t(x-p)\bigr)-q}{t},\\
F_0(x)=q+A(x-p).
\end{gathered}
\]
Then \(|F_t(x)-F_0(x)|\) is at most \(\eta\bigl(t|x-p|\bigr)|x-p|\leq\eta(t\varepsilon)\,\varepsilon\), which tends to \(0\) uniformly in \(x\) as \(t\to0\); so \(F\) is continuous on \(B\times[0,1]\). For \(x\neq p\), \(|F_t(x)-q|\geq\bigl(c-\eta(\varepsilon)\bigr)|x-p|>0\), including \(t=0\) and \(t=1\). So \(F\) is a homotopy of maps of pairs \((B,B\setminus p)\to(\mathbf R^m,\mathbf R^m\setminus q)\) from the affine map \(L(x)=q+A(x-p)\) to \(f\); in particular \(f(x)\neq q\) for \(x\neq p\) in \(B\). Hence \(f_*=L_*\). Now \(L=T_q\circ A\circ T_{-p}\), and by Lemma 3.1 each factor preserves the standard orientation when \(\det A>0\). Under the excision isomorphism \(H_m(B,B\setminus p)\cong H_m(\mathbf R^m,\mathbf R^m\setminus p)\) the class \(\mu^{\rm std}_p\) corresponds to itself, which proves the claim. \(\square\)

**Corollary 3.3.** Let \(M\) be an \(n\)-manifold with an atlas of charts \(\varphi_\alpha:U_\alpha\to\mathbf R^n\) whose coordinate changes \(\varphi_\beta\circ\varphi_\alpha^{-1}\) are differentiable with positive Jacobian determinant at every point. Then \(M\) has a unique orientation \(\mu\) such that each chart maps \(\mu_x\) to \(\mu^{\rm std}_{\varphi_\alpha(x)}\) under the isomorphisms
\[
\begin{aligned}
&H_n(M,M\setminus x)\cong H_n(U_\alpha,U_\alpha\setminus x)\\
&\quad\cong H_n(\varphi_\alpha(U_\alpha),\varphi_\alpha(U_\alpha)\setminus\varphi_\alpha(x)).
\end{aligned}
\]

**Proof.** Define \(\mu_x\) by one chart containing \(x\). For a second chart, Proposition 3.2 applied to the coordinate change at \(\varphi_\alpha(x)\) shows that both charts give the same class, since the local homology map of a homeomorphism agrees with that of its restriction to a small ball. The family is locally consistent because \(\mu^{\rm std}\) is and charts are homeomorphisms. Uniqueness is clear. \(\square\)

**Lemma 3.4.** Identify \(\mathbf C^d\) with \(\mathbf R^{2d}\) by \((z_1,\ldots,z_d)\mapsto(x_1,y_1,\ldots,x_d,y_d)\), \(z_k=x_k+iy_k\). For a complex matrix \(A\in GL_d(\mathbf C)\), the real determinant of \(A\) as an \(\mathbf R\)-linear map of \(\mathbf R^{2d}\) is \(|\det A|^2\).

**Proof.** For \(d=0\), both determinants are one. In positive dimension, both \(A\mapsto\det_{\mathbf R}A\) and \(A\mapsto|\det A|^2\) are multiplicative. The elimination in the proof of Lemma 3.1, carried out over \(\mathbf C\), writes \(A\) as a product of matrices \(I+cE_{jk}\) (\(j\neq k\), \(c\in\mathbf C\)) and one diagonal matrix \(\operatorname{diag}(1,\ldots,1,\lambda)\). The real form of \(I+cE_{jk}\) is \(I+N\) with \(N\) mapping the \((x_k,y_k)\)-plane into the \((x_j,y_j)\)-plane and the rest to zero, so \(N^2=0\) and \(\det_{\mathbf R}=1=|\det|^2\). The real form of the diagonal matrix is the identity except for the block \(\begin{pmatrix}a&-b\\b&a\end{pmatrix}\), \(\lambda=a+ib\), whose determinant is \(a^2+b^2=|\lambda|^2\). \(\square\)

**Corollary 3.5 (complex orientation).** Every complex manifold of complex dimension \(d\) has a canonical orientation as a real \(2d\)-manifold: in every holomorphic chart it corresponds to the standard orientation of \(\mathbf R^{2d}\), under the identification of Lemma 3.4. In particular it is \(R\)-oriented for every \(R\).

**Proof.** A holomorphic coordinate change \(F\) is differentiable as a real map, with real derivative the real form of its complex Jacobian matrix, which is invertible. By Lemma 3.4 its real Jacobian determinant is \(|\det(\partial F_j/\partial z_k)|^2>0\). Apply Corollary 3.3, and Proposition 2.3(3) for other coefficients. \(\square\)

The same argument shows that a holomorphic map with invertible complex derivative at a point, for example the analytic map of an étale morphism of complex varieties, sends the complex orientation at that point to the complex orientation at its image: in charts this is Proposition 3.2 with Lemma 3.4.

**Affine simplices.** For an affine \(N\)-simplex in \(\mathbf R^N\) with vertices \(v_0,\ldots,v_N\), we use the singular simplex \(\sigma:\Delta^N\to\mathbf R^N\) that is affine and sends the \(i\)-th vertex of \(\Delta^N\) to \(v_i\). Since
\[
\begin{aligned}
v_j-v_0&=(v_1-v_0)+(v_2-v_1)\\
&\quad+\cdots+(v_j-v_{j-1}),
\end{aligned}
\]
the determinant of the vectors \(v_1-v_0,\ldots,v_N-v_0\) equals the determinant of the consecutive differences \(v_1-v_0,v_2-v_1,\ldots,v_N-v_{N-1}\). For \(\tau_N\) the consecutive differences are \(e_1,e_2-e_1,\ldots,e_N-e_{N-1}\), with determinant \(1\).

**Lemma 3.6.** Let \(\sigma\) be the affine simplex with vertices \(v_0,\ldots,v_N\), with image \(S\), and let \(p\) be an interior point of \(S\). Then \([\sigma]=\varepsilon\,\mu^{\rm std}_p\) in \(H_N(\mathbf R^N,\mathbf R^N\setminus p;\mathbf Z)\), where \(\varepsilon\) is the sign of \(\det(v_1-v_0,\ldots,v_N-v_0)\).

**Proof.** First let \(\varepsilon=1\). The affine map \(L\) with \(L(w_i)=v_i\) satisfies \(L\circ\tau_N=\sigma\), since affine maps that agree on vertices agree. Its linear part \(A\) sends \(e_i=w_i-w_0\) to \(v_i-v_0\), so \(\det A>0\), and \(L=T_b\circ A\), where \(b=L(0)\) is the barycentre of \(S\). By Lemma 3.1, \([\sigma]=L_*o_N=L_*\mu^{\rm std}_0=\mu^{\rm std}_b\) in \(H_N(\mathbf R^N,\mathbf R^N\setminus b)\). Let \(C\subset\operatorname{int}S\) be a compact convex neighbourhood of the segment from \(b\) to \(p\), for example its closed \(r\)-neighbourhood for small \(r\). The boundary of \(\sigma\) lies in \(\partial S\), outside \(C\), so \(\sigma\) defines a class in \(H_N(\mathbf R^N,\mathbf R^N\setminus C)\) with image \(\mu^{\rm std}_b\) at \(b\). By Lemma 2.2 and Lemma 1.2(1) it is the class of \(\mu^{\rm std}\) on \(C\), so its image at \(p\) is \(\mu^{\rm std}_p\).

If \(\varepsilon=-1\), let \(\sigma'\) be the affine simplex with \(v_0\) and \(v_1\) exchanged. Writing \(u_i=v_i-v_0\), its determinant is
\[
\begin{aligned}
&\det(-u_1,u_2-u_1,\ldots,u_N-u_1)\\
&\quad=\det(-u_1,u_2,\ldots,u_N)\\
&\quad=-\det(u_1,\ldots,u_N)>0,
\end{aligned}
\]
so \([\sigma']=\mu^{\rm std}_p\) by the first case. Let \(L'\) be the affine map that exchanges \(v_0\) and \(v_1\) and fixes the other vertices; then \(L'\circ\sigma=\sigma'\), and \(L'\) fixes \(b\) and has determinant \(-1\). Let \(r\) be the orthogonal reflection in a hyperplane through \(b\). Then \(L'\circ r^{-1}\) has positive determinant and fixes \(b\), so by Lemma 3.1 (after translating \(b\) to \(0\)) \(L'_*=r_*\) on \(H_N(\mathbf R^N,\mathbf R^N\setminus b)\). The long exact sequence identifies this group with \(\tilde H_{N-1}\) of a sphere about \(b\), compatibly with \(r\), which restricts to a reflection of the sphere, of degree \(-1\) [Fomberg, Proposition 1.35(4)]. So \([\sigma']=-[\sigma]\) at \(b\), and at \(p\) by the argument with \(C\) above. Hence \([\sigma]=-\mu^{\rm std}_p\). \(\square\)

**Products.** For spaces \(X,Y\), open \(A\subset X\), \(B\subset Y\) and relative cycles \(c\) of \((X,A)\) and \(d\) of \((Y,B)\) with coefficients in \(R\), the chain \(S(c\otimes d)\) is a relative cycle of \((X\times Y,A\times Y\cup X\times B)\); its class is the **cross product** \([c]\times[d]\). By the properties of \(S\) recalled at the start, this is a well-defined bilinear map

\[
\begin{aligned}
&H_i(X,A)\otimes_RH_j(Y,B)\\
&\quad \longrightarrow H_{i+j}(X\times Y,A\times Y\cup X\times B),
\end{aligned}
\]

natural for maps of pairs. For manifolds and compact \(K\subset M\), \(L\subset N\), the union of \((M\setminus K)\times N\) and \(M\times(N\setminus L)\) is \((M\times N)\setminus(K\times L)\), so it maps \(H_i(M,M\setminus K)\otimes H_j(N,N\setminus L)\) to \(H_{i+j}(M\times N,(M\times N)\setminus(K\times L))\).

The shuffle map of [Thom classes and Euler classes, Section 4] sends \(c\otimes d\), for affine \(c:\Delta^p\to X\) and \(d:\Delta^q\to Y\) in Euclidean spaces, to a signed sum over the lattice paths from \((0,0)\) to \((p,q)\): the path through the vertices \((i_0,j_0),\ldots,(i_{p+q},j_{p+q})\) of \(\Delta^p\times\Delta^q\) contributes the affine simplex with vertices \((c(e_{i_l}),d(e_{j_l}))\), with the sign \(\varepsilon\) of the permutation that puts its \(p\) horizontal steps before its \(q\) vertical steps. These simplices cover \(c(\Delta^p)\times d(\Delta^q)\), and their interiors are disjoint. Indeed, in the coordinates \(1\geq s_1\geq\cdots\geq s_p\geq0\) on \(\Delta^p\) and \(1\geq t_1\geq\cdots\geq t_q\geq0\) on \(\Delta^q\) (\(s_i\) is the sum of the barycentric coordinates of the vertices \(i,\ldots,p\)), a lattice path corresponds to an interleaving of the two chains of inequalities, its simplex is the set of points satisfying the interleaved chain, every point satisfies at least one interleaved chain, and a point at which all \(p+q\) coordinates are distinct, and lie strictly between \(0\) and \(1\), satisfies exactly one, strictly.

**Lemma 3.7.** Identify \(\mathbf R^m\times\mathbf R^k\) with \(\mathbf R^{m+k}\), coordinates in the listed order. Then \(o_m\times o_k=o_{m+k}\).

**Proof.** If one dimension is zero, there is a single shuffle and shuffling the singular point with the other simplex gives that simplex under the coordinate identification. The coefficient of the point generator is one, so the claimed equality holds; this also covers two zero-dimensional factors. Assume both dimensions are positive for the calculation below. By the description above, \(S(\tau_m\otimes\tau_k)=\sum_\pi\varepsilon(\pi)\sigma_\pi\), a sum over lattice paths of affine simplices \(\sigma_\pi\) covering \(P=\tau_m\times\tau_k\) with disjoint interiors. Along a path, the consecutive differences of the vertices of \(\sigma_\pi\) are the vectors \((w_{i+1}-w_i,0)\) for horizontal steps and \((0,w'_{j+1}-w'_j)\) for vertical steps, where \(w_i\) and \(w'_j\) are the vertices of \(\tau_m\) and \(\tau_k\). Putting the horizontal steps first changes the determinant by the sign \(\varepsilon(\pi)\), after which it is the product of the determinants of the consecutive differences of \(\tau_m\) and of \(\tau_k\), both equal to \(1\). So \(\det\sigma_\pi\) has sign \(\varepsilon(\pi)\), and by Lemma 3.6, \(\varepsilon(\pi)[\sigma_\pi]=\mu^{\rm std}_p\) for every interior point \(p\) of \(\sigma_\pi\).

The point \(0\), the product of the barycentres, lies in the interior of \(P\). Choose a closed ball \(C\) about \(0\) inside \(\operatorname{int}P\), and a point \(p\in C\) all of whose coordinates in the sense above are distinct and strictly between \(0\) and \(1\); it lies in the interior of exactly one simplex \(\sigma_{\pi_0}\) and in no other. The boundary of \(S(\tau_m\otimes\tau_k)\) is \(S(\partial\tau_m\otimes\tau_k\pm\tau_m\otimes\partial\tau_k)\), carried by \(\partial P\), so the chain defines a class in \(H_{m+k}(\mathbf R^{m+k},\mathbf R^{m+k}\setminus C)\). At \(p\) the simplices \(\sigma_\pi\), \(\pi\neq\pi_0\), are chains in \(\mathbf R^{m+k}\setminus p\), so the image at \(p\) is \(\varepsilon(\pi_0)[\sigma_{\pi_0}]=\mu^{\rm std}_p\). By Lemma 2.2 the class on \(C\) is that of \(\mu^{\rm std}\), and its image at \(0\) is \(\mu^{\rm std}_0=o_{m+k}\). That image is \(o_m\times o_k\) by definition. \(\square\)

**Proposition 3.8 (product orientations).** Let \(\mu\) and \(\nu\) be \(R\)-orientations of manifolds \(M\) and \(N\) of dimensions \(m\) and \(k\). Then \(M\times N\) is an \((m+k)\)-manifold, and \((x,y)\mapsto\mu_x\times\nu_y\) is an \(R\)-orientation of it, the **product orientation**. If \(\mu\) and \(\nu\) come from atlases as in Corollary 3.3, the product orientation is the orientation of the product atlas. In particular the complex orientation of a product of complex manifolds is the product of their complex orientations.

**Proof.** \(M\times N\) is Hausdorff and second countable, and products of charts are charts. *Generators.* Choose charts \(\varphi,\psi\) about \(x,y\), composed with translations so that \(\varphi(x)=0\) and \(\psi(y)=0\). By excision and naturality of the cross product,
\[
\begin{aligned}
&\times:H_m(M,M\setminus x)\otimes H_k(N,N\setminus y)\\
&\quad\to H_{m+k}(M\times N,(M\times N)\setminus(x,y))
\end{aligned}
\]
is identified with the cross product for \((\mathbf R^m,\mathbf R^m\setminus0)\) and \((\mathbf R^k,\mathbf R^k\setminus0)\). By Lemma 1.2(2) the generators are \(\mu_x=u\,o_m\) and \(\nu_y=u'\,o_k\) with units \(u,u'\in R\), so \(\mu_x\times\nu_y=uu'\,o_{m+k}\) by Lemma 3.7, a generator. *Local consistency.* If \(D\) and \(E\) are compact neighbourhoods of \(x\) and \(y\) with classes \(\mu_D,\nu_E\) as in Definition 2.1, then \(D\times E\) is a compact neighbourhood of \((x,y)\), and by naturality \(\mu_D\times\nu_E\) has image \(\mu_{x'}\times\nu_{y'}\) at every \((x',y')\in D\times E\). *Atlases.* For charts \(\varphi\), \(\psi\) of the two atlases, translation (Lemma 3.1, applied factorwise) and Lemma 3.7 show that \(\varphi\times\psi\) maps \(\mu_x\times\nu_y\) to \(\mu^{\rm std}\) at \((\varphi(x),\psi(y))\); the coordinate changes of the product atlas have Jacobian determinant the product of two positive determinants, and Corollary 3.3 applies. *Complex manifolds.* Products of holomorphic charts are holomorphic, and the identification \(\mathbf C^a\times\mathbf C^b=\mathbf C^{a+b}\) of Lemma 3.4 is the identification \(\mathbf R^{2a}\times\mathbf R^{2b}=\mathbf R^{2a+2b}\) in the listed order. \(\square\)

## 4. Classes on compact subsets

**Theorem 4.1.** Let \(M\) be an \(n\)-manifold and \(K\subset M\) compact.

1. \(H_i(M,M\setminus K)=0\) for \(i>n\), and a class \(\alpha\in H_n(M,M\setminus K)\) is zero if and only if its image in \(H_n(M,M\setminus x)\) is zero for every \(x\in K\).
2. If \(x\mapsto\mu_x\) is a locally consistent family, for instance an \(R\)-orientation, there is a unique class \(\mu_K\in H_n(M,M\setminus K)\) whose image in \(H_n(M,M\setminus x)\) is \(\mu_x\) for every \(x\in K\).

**Proof.** If \(K=\emptyset\), the relative complex is zero and the conclusions hold. If \(n=0\), the direct sum of point complexes described above gives \(H_0(M,M\setminus K;R)=\bigoplus_{x\in K}R\) and no positive-degree homology. A class is determined by its coordinates, and the tuple \((\mu_x)_{x\in K}\) is the unique required class. We may therefore assume \(n\geq1\) and \(K\neq\emptyset\) in the remaining proof. *The Mayer–Vietoris sequence for complements.* Let \(A,B\subset M\) be compact. Put \(U=M\setminus A\), \(V=M\setminus B\), so that \(U\cup V=M\setminus(A\cap B)\) and \(U\cap V=M\setminus(A\cup B)\). The sequence of chain complexes

\[
\begin{aligned}
0&\to C(M)/C(U\cap V)\\
&\to C(M)/C(U)\oplus C(M)/C(V)\\
&\to C(M)/\bigl(C(U)+C(V)\bigr)\to0,
\end{aligned}
\]

with maps \(c\mapsto(c,c)\) and \((a,b)\mapsto a-b\), is exact. The inclusion \(C(U)+C(V)\to C(U\cup V)\) of the chains subordinate to the cover \(\{U,V\}\) of \(U\cup V\) is a chain homotopy equivalence [Fomberg, Proposition 1.25], so by the five lemma the natural map from \(C(M)/(C(U)+C(V))\) to \(C(M)/C(U\cup V)\) induces isomorphisms in homology. The long exact homology sequence (4.1) is

\[
\begin{aligned}
&\cdots\to H_{i+1}(M,M\setminus(A\cap B))\\
&\quad\to H_i(M,M\setminus(A\cup B))\\
&\quad\to H_i(M,M\setminus A)\oplus H_i(M,M\setminus B)\\
&\quad\to H_i(M,M\setminus(A\cap B))\to\cdots,
\end{aligned}
\]

natural in \(A\) and \(B\).

*Step 1: if the theorem holds for \(A\), \(B\) and \(A\cap B\), it holds for \(A\cup B\).* For \(i>n\), both neighbours of \(H_i(M,M\setminus(A\cup B))\) in (4.1) vanish, so it vanishes. For \(i=n\), the term on the left vanishes, so \(H_n(M,M\setminus(A\cup B))\) injects into the direct sum; a class that vanishes at every point of \(A\cup B\) vanishes in both summands by (1) for \(A\) and \(B\), hence is zero. For (2), the classes \(\mu_A\) and \(\mu_B\) have the same image \(\mu_{A\cap B}\), by the uniqueness for \(A\cap B\); by exactness they come from a class in \(H_n(M,M\setminus(A\cup B))\), which restricts correctly at every point and is unique by (1).

*Step 2: \(K\) a finite union of compact sets \(K_1,\ldots,K_m\) in one chart domain, each with convex image.* Induction on \(m\), using Step 1 with \(A=K_1\cup\cdots\cup K_{m-1}\) and \(B=K_m\): the set \(A\cap B=\bigcup_{j<m}(K_j\cap K_m)\) is a union of \(m-1\) sets of the same kind, since intersections of convex sets are convex (an empty set is harmless, as \(H_\bullet(M,M)=0\)). The case \(m=1\) is Lemma 1.2(1) together with Lemma 2.2.

*Step 3: \(K\) arbitrary compact in a chart domain \(U\), with chart \(\varphi\).* Choose an open set \(U'\) with \(K\subset U'\) and \(\overline{U'}\) compact inside \(U\). Let \(\alpha\in H_i(M,M\setminus K)\) be represented by a chain \(z\) of \(M\) whose boundary is a chain in \(M\setminus K\); the boundary is carried by a compact set \(E\subset M\setminus K\). The compact sets \(\varphi(K)\) and \(\varphi(E\cap\overline{U'})\) are disjoint; let \(\delta>0\) be smaller than their distance and than the distance from \(\varphi(K)\) to \(\mathbf R^n\setminus\varphi(U')\). Cover \(\varphi(K)\) by finitely many closed cubes of diameter less than \(\delta\), each meeting \(\varphi(K)\). Their union pulls back to a compact set \(K'\supset K\) inside \(U'\), disjoint from \(E\), and a finite union as in Step 2. So \(z\) defines \(\alpha'\in H_i(M,M\setminus K')\) mapping to \(\alpha\). If \(i>n\), then \(\alpha'=0\) by Step 2, so \(\alpha=0\). If \(i=n\) and \(\alpha\) vanishes at every point of \(K\), then for each cube \(Q\) (pulled back to \(M\)) the image of \(\alpha'\) in \(H_n(M,M\setminus Q)\) vanishes, because by Lemma 1.2(1) it is detected at a point of \(Q\cap K\); hence \(\alpha'\) vanishes at every point of \(K'\), and \(\alpha'=0\) by Step 2. For (2), restrict the class \(\mu_{K'}\) given by Step 2 for any such \(K'\); uniqueness follows from (1).

*Step 4: general \(K\).* Cover \(K\) by finitely many chart domains \(U_1,\ldots,U_m\) and write \(K=K_1\cup\cdots\cup K_m\) with \(K_j\subset U_j\) compact (shrink the cover: every point of \(K\) has a compact neighbourhood inside some \(U_j\), and finitely many of these cover \(K\)). Induction on \(m\) with Step 1, \(A=K_1\cup\cdots\cup K_{m-1}\) and \(B=K_m\): \(A\cap B\) and \(B\) are compact subsets of \(U_m\), covered by Step 3, and \(A\) by the induction hypothesis. \(\square\)

*Reference:* this is the structure theorem of [Hatcher, Lemma 3.27]; [Miller, Theorem 32.1] treats it as the orientation theorem.

## 5. Fundamental classes

Every class \(\alpha\in H_n(M)\) defines a locally consistent family \(x\mapsto\alpha_x\), \(\alpha_x\) being its image in \(H_n(M,M\setminus x)\); local consistency holds with \(\alpha_D\) the image of \(\alpha\). On a connected manifold a locally consistent family vanishing at one point vanishes everywhere, by Proposition 2.3(1) applied to the family and the zero family.

**Corollary 5.1.** Let \(M\) be a closed (compact) connected \(n\)-manifold. Then \(H_i(M;R)=0\) for \(i>n\), and \(\alpha\mapsto(\alpha_x)\) is an isomorphism from \(H_n(M;R)\) onto the module of locally consistent families. If \(M\) is \(R\)-orientable, \(H_n(M;R)\to H_n(M,M\setminus x;R)\) is an isomorphism for every \(x\), and the class \([M]=\mu_M\) of an \(R\)-orientation \(\mu\) is a generator, the **fundamental class**.

**Proof.** Apply Theorem 4.1 with \(K=M\), where \(M\setminus K=\emptyset\): part 1 gives the vanishing and injectivity, part 2 surjectivity. If \(\mu\) is an \(R\)-orientation, then every locally consistent family is determined by its value at one point \(x\), by Proposition 2.3(1); and for every \(r\in R\) the family \(r\mu\) has value \(r\mu_x\). So evaluation at \(x\) is an isomorphism onto \(H_n(M,M\setminus x)\cong R\), and \(\mu_M\) maps to the generator \(\mu_x\). \(\square\)

**Corollary 5.2.** If \(M\) is a connected noncompact \(n\)-manifold, then \(H_i(M;R)=0\) for \(i\geq n\).

**Proof.** Let \(\alpha\in H_i(M)\) be represented by a cycle \(z\), carried by a compact set \(E\), and choose an open \(U\supset E\) with compact closure; put \(V=M\setminus\overline U\), which is open, and nonempty because \(M\) is not compact. Since \(U\) and \(V\) are disjoint, \(H_i(U\cup V,V)=H_i(U)\). Consider the exact sequence of the triple \((M,U\cup V,V)\):

\[
\begin{aligned}
H_{i+1}(M,U\cup V)&\longrightarrow H_i(U\cup V,V)\\
&\longrightarrow H_i(M,V).
\end{aligned}
\]

Here \(U\cup V=M\setminus\partial U\) with \(\partial U=\overline U\setminus U\) compact, so the first group vanishes for \(i\geq n\) by Theorem 4.1(1), and \(H_i(M,V)=H_i(M,M\setminus\overline U)\). Hence \(H_i(U)\to H_i(M,M\setminus\overline U)\) is injective for \(i\geq n\). For \(i>n\) the target vanishes, so the class of \(z\) in \(H_i(U)\) is zero, and so is \(\alpha\). For \(i=n\), the image of the class of \(z\) is determined, by Theorem 4.1(1), by its values \(\alpha_x\) at the points of \(\overline U\). The family \(x\mapsto\alpha_x\) on \(M\) vanishes at every point outside \(E\), since there \(z\) is a chain in \(M\setminus x\); such points exist, so the family vanishes everywhere. Hence the class of \(z\) in \(H_n(U)\) is zero, and \(\alpha=0\). \(\square\)

For a class \(a\in H^i(X,A;R)\) and \(\alpha\in H_i(X,A;R)\), write \(\langle a,\alpha\rangle\in R\) for the Kronecker pairing, the value of a representing cocycle on a representing relative cycle.

**Corollary 5.3 (products).** Let \(\mu,\nu\) be \(R\)-orientations of manifolds \(M,N\) of dimensions \(m,k\), give \(M\times N\) the product orientation, and let \(K\subset M\), \(L\subset N\) be compact. Then \((\mu\times\nu)_{K\times L}=\mu_K\times\nu_L\). For \(a\in H^m(M,M\setminus K;R)\) and \(b\in H^k(N,N\setminus L;R)\), the external product
\[
\begin{aligned}
&a\times b\in H^{m+k}\bigl(M\times N,\\
&\qquad(M\times N)\setminus(K\times L);R\bigr)
\end{aligned}
\]
satisfies

\[
\langle a\times b,\mu_K\times\nu_L\rangle=\langle a,\mu_K\rangle\,\langle b,\nu_L\rangle .
\]

In particular, for closed \(M\) and \(N\), \([M\times N]=[M]\times[N]\) and \(\langle a\times b,[M\times N]\rangle=\langle a,[M]\rangle\langle b,[N]\rangle\).

**Proof.** Both classes restrict to \(\mu_x\times\nu_y\) at every \((x,y)\in K\times L\), by naturality of the cross product, so they are equal by Theorem 4.1(2). For the pairing, let \(a,b\) be represented by relative cocycles and \(\mu_K,\nu_L\) by relative cycles \(c,d\). The cochain of \(a\times b\) is \((a\otimes b)\circ A\), where \((a\otimes b)(c'\otimes d')=a(c')b(d')\) when the degrees match and zero otherwise. Lemma 4.1 of [Thom classes and Euler classes](https://github.com/KokunoYumeto/open-math-courses/blob/main/docs/courses/DG-CHAR/thom-classes-and-euler-classes.md#2-making-singular-chains-small) gives a homotopy \(h\) with \(\partial h+h\partial=1-AS\) on the tensor complex, preserving products of subspaces. Hence

\[
\begin{aligned}
&(a\times b)\bigl(S(c\otimes d)\bigr)=(a\otimes b)(c\otimes d)\\
&\quad -(a\otimes b)\bigl(\partial h(c\otimes d)\bigr)\\
&\quad -(a\otimes b)\bigl(h\partial(c\otimes d)\bigr).
\end{aligned}
\]

The second term vanishes because \((a\otimes b)\circ\partial=\delta a\otimes b\pm a\otimes\delta b=0\) for cocycles. In the third, \(\partial(c\otimes d)\) lies in the sum of \(C_\bullet(M\setminus K)\otimes C_\bullet(N)\) and \(C_\bullet(M)\otimes C_\bullet(N\setminus L)\), which \(h\) preserves and on which \(a\otimes b\) vanishes. So the left side is \(a(c)b(d)\). \(\square\)

## 6. Exercises

**Exercise 6.1.** Let \(S\subset\mathbf R^n\) be an affine \(n\)-simplex with barycentre \(b\), \(\sigma:\Delta^n\to S\) an affine homeomorphism, and \(\sigma'\) the affine simplex obtained by exchanging two vertices of \(\sigma\). Show that \([\sigma]\) generates \(H_n(\mathbf R^n,\mathbf R^n\setminus b;\mathbf Z)\) and that \([\sigma']=-[\sigma]\).

*Solution.* The first claim is Lemma 1.2(3). Let \(L\) be the affine map of \(\mathbf R^n\) that exchanges the two vertices and fixes the others; it fixes \(b\) and \(L\circ\sigma=\sigma'\), since affine maps agreeing on vertices agree. Its linear part fixes the \(n-1\) independent vectors \(v_k-b\) of the fixed vertices and reverses the difference of the exchanged vertices, so its determinant is \(-1\). Let \(r\) be the orthogonal reflection in a hyperplane through \(b\). Then \(L\circ r^{-1}\) has positive determinant, so by Lemma 3.1 (after translating \(b\) to \(0\)) it acts trivially on local homology at \(b\), and \(L_*=r_*\). The long exact sequence identifies \(H_n(\mathbf R^n,\mathbf R^n\setminus b)\) with \(\tilde H_{n-1}\) of a sphere about \(b\), compatibly with \(r\), and \(r\) restricts to a reflection of that sphere, of degree \(-1\) [Fomberg, Proposition 1.35(4)]. So \([\sigma']=L_*[\sigma]=-[\sigma]\).

**Exercise 6.2.** In \(\mathbf C=\mathbf R^2\), show that the connecting map \(H_2(\mathbf R^2,\mathbf R^2\setminus0;\mathbf Z)\to H_1(\mathbf R^2\setminus0;\mathbf Z)\) sends the standard generator \(o_2\) to the class of the counterclockwise loop \(t\mapsto e^{2\pi it}\).

*Solution.* The connecting map sends \([\tau_2]\) to the class of the cycle \(\partial\tau_2=[w_1,w_2]-[w_0,w_2]+[w_0,w_1]\), with \(w_0=(-\tfrac13,-\tfrac13)\), \(w_1=(\tfrac23,-\tfrac13)\), \(w_2=(-\tfrac13,\tfrac23)\). For a path \(\gamma\) with reverse \(\bar\gamma\), the singular \(2\)-simplex \(\gamma\circ q\), where \(q:\Delta^2\to\Delta^1\) is the affine map sending the vertices to \(v_0,v_1,v_0\), has boundary \(\bar\gamma-c+\gamma\) with \(c\) constant; a constant \(1\)-simplex is the boundary of a constant \(2\)-simplex, so \(\bar\gamma\) is homologous to \(-\gamma\). Likewise, for paths \(\gamma,\delta\) with \(\gamma(1)=\delta(0)\), a singular \(2\)-simplex with edges \(\gamma\), \(\delta\) and the concatenation \(\gamma\cdot\delta\) shows that \(\gamma+\delta\) is homologous to \(\gamma\cdot\delta\). So the class is that of the closed polygonal loop \(w_0\to w_1\to w_2\to w_0\), which runs counterclockwise around \(0\). Radial projection onto the unit circle is a homotopy in \(\mathbf R^2\setminus0\) to a counterclockwise parametrization of the circle, homotopic to \(t\mapsto e^{2\pi it}\).

**Exercise 6.3.** Show that a complex projective space \(\mathbf P^m\) is a closed orientable manifold of real dimension \(2m\), so \(H_{2m}(\mathbf P^m;\mathbf Z)\cong\mathbf Z\).

*Solution.* \(\mathbf P^m\) is a compact connected complex manifold, oriented canonically by Corollary 3.5; apply Corollary 5.1.

## References

- [Fomberg] Y. Fomberg, *Algebraic Topology*, notes on lectures by Nir Lazarovich, Spring 2025; the homology part of the core course *Algebraic Topology*. [Native source](https://yp.srht.site/notes/math/algebraic_topology.tex), [PDF](https://yp.srht.site/notes/math/algebraic_topology.pdf).
- [Hatcher] A. Hatcher, *Algebraic Topology*, Cambridge University Press 2002; freely available from the author. <https://pi.math.cornell.edu/~hatcher/AT/ATpage.html>
- [Miller] H. Miller, *Algebraic Topology I: Lecture Notes* (MIT 18.905, 2016). <https://ocw.mit.edu/courses/18-905-algebraic-topology-i-fall-2016/>
- [Roberts] D. M. Roberts, *Algebraic Topology* (lecture notes, 2019); the cohomology part of the core course *Algebraic Topology*. <https://github.com/DavidMichaelRoberts/AlgebraicTopology2019>
