# Lie’s theory of transformation groups

Analytic local transformation groups, parameters, flows, complete systems, the three fundamental theorems, structure and homogeneous actions, jets and contact transformations, classification, and the Riemann–Helmholtz problem. Twelve lessons contain proofs, examples, exercises and solutions. The general Lie–Tresse finite-generation theorem and the full assigned classification catalogues are not proved here. Historical readings comprise the explicitly identified selections.

The twelve editable Markdown lessons are in `LIE-TG/src/`. The `figures/` directory contains editable SVG diagrams, the parallel-curves image and its Python plotting source. Formulae are written in LaTeX notation. Prerequisite references identify the programme lessons and results used.

Original exposition and English translations: CC0 1.0. German historical originals: public domain. Authorship appears in each lesson and diagram.
