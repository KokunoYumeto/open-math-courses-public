# Lie’s theory of transformation groups

Analytic local transformation groups, parameters, flows, complete systems, the three fundamental theorems, structure and homogeneous actions, jets and contact transformations, classification, and the Riemann–Helmholtz problem. Twelve lessons contain proofs, examples, exercises and solutions. Lesson 9 proves finite differential generation, affine geometric quotients and finite/formal orbit separation for its stated induced point-action setting. The compatible equation-only action generality and the full assigned classification catalogues are outside the proofs included here. Historical readings comprise the explicitly identified selections.

The twelve editable Markdown lessons are in `LIE-TG/src/`. The `LIE-TG/figures/` directory contains editable SVG diagrams and their reproducible Python sources where provided, together with the parallel-curves image and its plotting source. Formulae use LaTeX notation. Prerequisite references identify the programme lessons and results used.

Original exposition and English translations: CC0 1.0. German historical originals: public domain. Authorship appears in each lesson and diagram.
