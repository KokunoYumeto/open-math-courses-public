# Incompressible flow: foundations and forced equations

A course on incompressible fluid equations, from pressure, energy, vorticity and scaling to weak and strong solutions, residual stresses and forced-flow constructions. It supplies the foundations for studying singularity constructions and their exact force and regularity requirements.

Seventeen complete lesson drafts, self-checked by GPT-6 Astra at Ultra. No independent review of this version is claimed. The rest of the course is in preparation.

## Available lessons

1. [Forces, energy and vorticity in incompressible flow](src/forces-energy-and-vorticity.md)
2. [Pressure and the divergence-free projection](src/pressure-and-the-divergence-free-projection.md)
3. [Weak solutions on a periodic box](src/weak-solutions-on-a-periodic-box.md)
4. [Weak solutions in three-dimensional space](src/weak-solutions-in-three-dimensional-space.md)
5. [Strong solutions and continuation](src/strong-solutions-and-continuation.md)
6. [Velocity bounds and uniqueness](src/velocity-bounds-and-uniqueness.md)
7. [Critical mild solutions](src/critical-mild-solutions.md)
8. [Vorticity, strain and continuation](src/vorticity-strain-and-continuation.md)
9. [Euler solutions and vorticity continuation](src/euler-solutions-and-vorticity-continuation.md)
10. [Critical velocity tails and weighted heat estimates](src/critical-velocity-tails-and-weighted-heat-estimates.md)
11. [Moving annuli and localized vorticity energy](src/moving-annuli-and-localized-vorticity-energy.md)
12. [Global nonlinear energy and total speed](src/global-nonlinear-energy-and-total-speed.md)
13. [Selecting an annulus and controlling local velocity](src/selecting-an-annulus-and-controlling-local-velocity.md)
14. [Interior vorticity bounds on an actual annulus](src/interior-vorticity-bounds-on-an-actual-annulus.md)
15. [Frequency backpropagation with the original parameters](src/frequency-backpropagation-with-the-original-parameters.md)
16. [Iterated backpropagation and total speed](src/iterated-backpropagation-and-total-speed.md)
17. [Original vorticity mass and a regularity interval](src/original-vorticity-mass-and-a-regularity-interval.md)

Each chapter includes complete derivations and five solved exercises. The second supplies Fourier inversion and Parseval, the exact pressure projection on the whole space and a periodic box, the constant mode, the Euler bilinear cancellation and the viscous integral equation. The third constructs periodic Leray–Hopf solutions with arbitrary box lengths, positive viscosity, nonzero mean and forces in L2 in time with values in H−1. It proves compactness, the energy inequality, pressure recovery and agreement with a regular solution, including a stability estimate when forces differ. The fourth proves the whole-space construction in three dimensions, including uniform spatial tails, compactness, low-frequency pressure and regular comparison. It also extends both periodic and whole-space existence to the sum of L1-time L2 and L2-time H−1 forces, with complete modified estimates. The fifth constructs H1 strong solutions on both domains, proves stability and maximal continuation, and supplies exact source-comparison counterexamples. The sixth proves the nonendpoint velocity criterion for the energy class, a small L3 endpoint criterion, full-force relative-energy estimates and exact boundary maps with all wall work and surface forces retained. The seventh proves critical local construction, full-force and pressure recovery, energy-class uniqueness, stability and continuation, the complete homogeneous construction, and small-data global existence with arbitrary periodic means. Its source comparisons retain the initial trace and test completeness explicitly. The eighth supplies exact strain reconstruction, enstrophy, full-force vorticity and strain continuation, finite-sum criteria and a small endpoint tail. Its source corrections include the forced strain sign, pressure-Hessian pairing and an exact compact flow testing the pointwise alignment inference.

The ninth proves Euler local existence, top-norm continuous dependence and Beale–Kato–Majda continuation with the original force, pressure and arbitrary periodic mean. Its exact source comparisons and compact multiscale example include a strain criterion and an inspected reproducible figure.

The tenth proves continuation from the actual large-value velocity tail, an exact concentration example, the weighted heat identity and both finite Carleman estimates with original viscosity, additive residuals and time endpoints. Source repairs and complete exercises retain the Gaussian weight and exact frequency sums. The general large L3 endpoint still requires its dynamical proof.

The eleventh proves the original moving-annulus energy identity, a repaired radius average, complete weighted Sobolev and localized curl estimates, and the finite stretching and force budget. Both harmonic and sphere contributions remain explicit. Five solved exercises include the exact averaging test and physical zoom. Two reproducible figures show the signed flux and boundary lift.

The twelfth proves global nonlinear energy and the complete total-speed estimate with the original viscosity, actual heat field and full force. Exact annular heat/Leray kernels, every low-frequency contribution and all four tensor interactions enter the proof. Five solved exercises retain Gaussian constants, the source-scale polynomial, actual boundary displacement and the physical zoom.

The thirteenth selects one actual annulus for the initial data and both force classes, proves exact local heat propagation and closes every term of the energy budget. Complete cutoff div-curl and Fourier estimates give the local L4-time velocity bound, and the full localized vorticity equation retains every force and boundary contribution.

The fourteenth completes the positive-time annular heat iteration. Six exact spatial gains, Holder vorticity and full Newton maps retain every cutoff, point mass, boundary field and original-force term. An explicit height and heat-target choice produces arbitrarily small velocity, vorticity and first derivatives on an actual unforced or compact-force receiving annulus.

The fifteenth proves original-viscosity frequency backpropagation with the same amplitude, exact physical time and spatial bounds, complete Fourier interactions and all kernel tails. It proves the original source hierarchy and finite backward-chain termination.

The sixteenth proves quantitative iteration from the original total-speed bound, with exact earlier times, frequencies and displacement. Complete hierarchy comparison gives the source-stated time separation. Full persistence intervals strengthen the constants, and an entire earlier frequency set retains a positive reciprocal-square sum.

The seventeenth recovers the original vorticity mass from the full inverse-curl kernel and constructs a quantitative regularity interval with original viscosity. Every heat cutoff, Newton boundary field and point mass remains explicit. The same vorticity mass survives on a definite interval meeting the finite Gaussian coefficient bounds. Exercises optimize the amplitude-duration allocation and extend the earlier heat interval while retaining full Gaussian geometry.

The series continues toward the human forced-flow constructions, the Alpöge–Buckmaster programme, OpenAI's proposed construction and subsequent mathematical derivations. Their full proofs and remaining questions will be supplied in the corresponding lessons; these foundation chapters do not establish a singularity theorem.

[Reader](../../docs/courses/NS-FLUID/index.html) · [Offline reader and sources](../../docs/downloads/NS-FLUID-reader-and-source.zip) · [Rights and sources](LICENSES.md)
