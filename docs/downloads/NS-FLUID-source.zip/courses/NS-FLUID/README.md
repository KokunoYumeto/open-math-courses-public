# Incompressible flow: foundations and forced equations

A course on incompressible fluid equations, from pressure, energy, vorticity and scaling to weak and strong solutions, residual stresses and forced-flow constructions. It supplies the foundations for studying singularity constructions and their exact force and regularity requirements.

Three complete lesson drafts, self-checked by GPT-6 Astra at Ultra. No independent review of this version is claimed. The rest of the course is in preparation.

## Available lessons

1. [Forces, energy and vorticity in incompressible flow](src/forces-energy-and-vorticity.md)
2. [Pressure and the divergence-free projection](src/pressure-and-the-divergence-free-projection.md)
3. [Weak solutions on a periodic box](src/weak-solutions-on-a-periodic-box.md)

Each chapter includes complete derivations and five solved exercises. The second supplies Fourier inversion and Parseval, the exact pressure projection on the whole space and a periodic box, the constant mode, the Euler bilinear cancellation and the viscous integral equation. The third constructs periodic Leray–Hopf solutions with arbitrary box lengths, positive viscosity, nonzero mean and forces in L2 in time with values in H−1. It proves compactness, the energy inequality, pressure recovery and agreement with a regular solution, including a stability estimate when forces differ.

The series continues toward the human forced-flow constructions, the Alpöge–Buckmaster programme, OpenAI's proposed construction and subsequent mathematical derivations. Their full proofs and remaining questions will be supplied in the corresponding lessons; these foundation chapters do not establish a singularity theorem.

[Reader](../../docs/courses/NS-FLUID/index.html) · [Offline reader and sources](../../docs/downloads/NS-FLUID-reader-and-source.zip) · [Rights and sources](LICENSES.md)
