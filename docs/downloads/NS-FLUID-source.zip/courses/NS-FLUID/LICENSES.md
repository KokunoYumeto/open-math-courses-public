# Rights and sources

The independently authored mathematical text, proofs, exercises and solutions in this course are dedicated to the public domain under [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/).

The cited papers retain their own rights. Their text is not included in the course download. Mathematical definitions and arguments in the lesson are independently expressed and proved there.

The offline reader includes MathJax under its Apache 2.0 licence and fonts under the component terms distributed in assets/mathjax/LICENSE and assets/mathjax/FONT-LICENSES.txt. Those software and font terms are separate from the mathematical text dedication.
