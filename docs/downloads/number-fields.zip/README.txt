Number fields

Open docs/index.html. All seventeen lessons, editable Markdown, nine supporting programme sources, four supporting readers, original diagrams and reproducible finite certificates are included. Maths rendering software and fonts are bundled. Additional programme prerequisites require repository access; see docs/package-dependencies.html.

Original mathematics: CC0 1.0, with exact authorship and cited human works preserved. Third-party software and fonts retain their supplied licences. See docs/licensing.html. This package does not claim independent mathematical review or complete transitive prerequisite closure.
