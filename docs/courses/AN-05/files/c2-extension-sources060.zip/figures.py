"""Original CC0 diagrams for C1-C26/O1-O6; numeric samples are not proof."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OWNED = Path(__file__).resolve().parent
OUT = OWNED / "figures"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,
                    "axes.spines.top":False,"axes.spines.right":False,
                    "figure.facecolor":"white","savefig.facecolor":"white"})


def positive_flow(z, s, alpha=.5):
    """Solve the exact separated O3 equation using a monotone ratio residual."""
    z = np.asarray(z,dtype=float)
    lo = np.full_like(z,.5); hi = np.full_like(z,1.5)
    for _ in range(90):
        ratio = (lo+hi)/2
        log = np.log(ratio)
        residual = (-np.expm1(-alpha*log)/alpha
                    -z**(2+2*alpha)*np.expm1((2+alpha)*log)/(2+alpha)
                    -s*z**alpha)
        hi = np.where(residual>0,ratio,hi)
        lo = np.where(residual<=0,ratio,lo)
    return z*(lo+hi)/2


def flow_figure():
    alpha=.5; s0=1/16
    fig,axes=plt.subplots(1,3,figsize=(15,5.1))
    z=np.linspace(-.12,.12,500)
    axes[0].plot(z,abs(z)**(2+alpha)/(2+alpha),color="#536F88",lw=2,label=r"$f=0: t=|x|^{5/2}/(5/2)$")
    for initial in [-.1,-.05,0,.05,.1]:
        ss=np.linspace(-s0,s0,160)
        if initial==0: xx=np.zeros_like(ss)
        else: xx=np.sign(initial)*np.array([positive_flow(np.array([abs(initial)]),s,alpha)[0] for s in ss])
        tt=ss+abs(xx)**(2+alpha)/(2+alpha)
        axes[0].plot(xx,tt,color="#B87535",lw=1.4)
    axes[0].set(xlabel="x",ylabel="t",title="Exact normalized flow: f(F(s,z)) = s",
                xlim=(-.125,.125),ylim=(-.07,.07))
    axes[0].legend(fontsize=9,loc="upper left")
    zz=np.geomspace(1e-6,.12,500)
    for s,c in [(s0,"#1B7189"),(-s0,"#AD6438")]:
        xx=positive_flow(zz,s,alpha)
        axes[1].semilogx(zz,(xx-zz)/zz**(1+alpha),lw=2,c=c,label=f"s = {s:+.4f}")
        axes[1].axhline(s,color=c,ls="--",lw=1)
        axes[2].semilogx(zz,abs((xx-zz)/zz**2),lw=2,c=c,label=f"|s| = {abs(s):.4f}")
    axes[1].set(xlabel="positive initial z (log scale)",ylabel=r"$(X(s,z)-z)/z^{3/2}$",
                title=r"Proved limit is s; alpha = 1/2",ylim=(-.075,.075))
    axes[1].legend(fontsize=9)
    axes[2].set(xlabel="positive initial z (log scale)",ylabel=r"$|X(s,z)-z|/z^2$",
                title="A finite C2 Taylor coefficient is impossible")
    axes[2].text(.002,40,r"$X_z(s,0)=1$"+"\n"+r"$|X-z|/z^2\sim |s|z^{-1/2}$",fontsize=10)
    fig.suptitle("A C2 surface can have a normalized flow that is only C1",fontsize=16,y=.995)
    fig.text(.5,.02,"Exact p=tau^2-xi^2; r=1/4, |z|<=1/8, |s|<=1/16. Noncharacteristic p(df)>=15/16; nonzero constrained tangencies are empty.\n"
             "O1-O5 prove the regularity obstruction. Curves are numerical samples of the exact separated equation, not a uniqueness counterexample.\n"
             "Original diagram; source comparison: Hörmander IV, adapted-coordinate paragraph, printed247; G25-G29.",ha="center",fontsize=9)
    fig.tight_layout(rect=(0,.135,1,.93))
    fig.savefig(OUT/"C2-normalized-flow-obstruction.png",dpi=180);plt.close(fig)


def barrier_figure():
    a=1/20; c=4.; eps=1/5; b=7/50
    # Exact stationarity polynomial of the stated top envelope.
    lo=0.;hi=.02
    for _ in range(90):
        w=(lo+hi)/2
        derivative=12.8*w**3-7.6*w+.02
        if derivative>0:lo=w
        else:hi=w
    xm=a+(lo+hi)/2;tm=-c*(xm-a)**2;maximum=tm+eps*(tm*tm+xm*xm)
    xs=np.linspace(-b,b,1000);top=-c*np.maximum(abs(xs)-a,0)**2
    # Near-zero branch of t+eps(t^2+x^2)=M.
    level=(-1+np.sqrt(1+4*eps*(maximum-eps*xs*xs)))/(2*eps)
    fig,(ax,bx)=plt.subplots(1,2,figsize=(13.4,6.2),gridspec_kw={"width_ratios":[1.1,1]})
    ax.fill_between(xs,-b,top,color="#DDEBF6",label="potential support envelope F* (no PDE solution asserted)")
    ax.plot(xs,top,color="#537789",lw=2,label=r"$t=-4(|x|-1/20)_+^2$")
    ax.plot(xs,level,color="#B06B32",lw=2.2,label=r"$g=M,\ g=t+(t^2+x^2)/5$")
    ax.plot([-a,a],[0,0],color="#A52F43",lw=4,label="entire contact K*")
    ax.scatter([xm,-xm],[tm,tm],s=38,c="#B06B32",zorder=8)
    ax.annotate("interior support maxima\nlie just below f=0",xy=(xm,tm),xytext=(.01,-.048),
                arrowprops={"arrowstyle":"->","color":"#B06B32"},fontsize=10,color="#92531F")
    ax.axhline(0,color="#C5CACE",lw=.7)
    ax.set(xlim=(-b,b),ylim=(-b,.025),xlabel="x",ylabel="t",
           title="Compact contact prevents an outer-boundary maximum")
    ax.legend(fontsize=8,loc="lower left")
    for level_m,label,color in [(0.,"original weak surface f=0","#A52F43"),
                                 (maximum,"strict barrier at the support maximum","#B06B32")]:
        if level_m==0:curve=np.zeros_like(xs)
        else:curve=(-1+np.sqrt(1+4*eps*(level_m-eps*xs*xs)))/(2*eps)
        bx.plot(xs,curve,lw=2,c=color,label=label)
    bx.plot(xs,top,color="#537789",lw=1.5)
    bx.scatter([xm,-xm],[tm,tm],s=35,c="#B06B32",zorder=8)
    bx.text(-.132,-.007,r"$p=\tau^2-\xi^2+\eta^2$; shown slice y=0"+"\n"+
            r"$H_p^2 f=0$; $H_p^2g=8\epsilon|\zeta|^2>0$"+"\n"+
            r"$p(dg)$ stays nonzero on the plotted box",fontsize=10)
    bx.set(xlim=(-b,b),ylim=(-.012,.002),xlabel="x",ylabel="t (vertical scale enlarged)",
           title="Positive quadratic, with changed level and tangency")
    bx.legend(fontsize=8,loc="lower left")
    fig.suptitle("The C2 extension uses a strict compact interior maximum",fontsize=16,y=.99)
    fig.text(.5,.018,"Exact illustrative constants: a=1/20, c=4, O=(-7/50,7/50)^2, epsilon=1/5; q=t^2+x^2+y^2 in the full three-dimensional symbol.\n"
             "F* is a specified geometric envelope, not the support of a nonzero solution. Maxima are sampled from an exact cubic; C1-C26 prove the general theorem.\n"
             "General epsilon/R/eta are selected by C19-C23. Original diagram; strict analytical input: AN05-L057 U1-U12; Hörmander IV, Theorem28.3.4, printed241-242.",ha="center",fontsize=9)
    fig.tight_layout(rect=(0,.13,1,.93))
    fig.savefig(OUT/"C2-positive-quadratic-compact-maximum.png",dpi=180);plt.close(fig)
    return {"a":"1/20","c":4,"O_half_width":"7/50","epsilon":"1/5","x_max_sample":xm,
            "t_max_sample":tm,"M_sample":maximum,"support_is_geometric_envelope":True,
            "nonzero_PDE_solution_asserted":False,"general_epsilon_threshold_claimed":False}


if __name__=="__main__":
    flow_figure(); parameters=barrier_figure()
    (OUT/"figure-parameters.json").write_text(json.dumps({"flow":{"alpha":"1/2","r":"1/4",
         "z_limit":"1/8","s_limit":"1/16","proof":"O1-O5"},"barrier":parameters,
         "proof":"C1-C26","license":"CC0-1.0","figures_are_proof":False},indent=2)+"\n",encoding="utf8")
