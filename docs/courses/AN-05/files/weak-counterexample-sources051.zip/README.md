# Reproduce the two counterexample diagrams

Use Python with NumPy and Matplotlib. In this extracted directory, run:

    python figures.py

The unmodified source writes both PNGs and the parameter file into its local figures/ directory. Compare each PNG with the SHA256 and size in expected-outputs.json. The same images appear in the lesson; the source makes no edits to a course.

The first plot uses the fixed surface psi=t-x^2/4, the actual support t<=0, the entire singleton contact and the real fiber p=tau^2. The second uses the exact sample L=2, exponents ell=-8, ell_prime=-12, m=-16, n=-4, and frequency omega=8. The lower panel samples the proved derivative-envelope factors; it does not establish the derivative or PDE proof.

The construction is proved in lesson equations W1–W15. Human sources: Jean Leray, *Équations hyperboliques non-strictes*, Séminaire Jean Leray no.2 (1964–1965), Sections 1–2, printed pp.3–13; Lars Hörmander, *The Analysis of Linear Partial Differential Operators IV*, Section 28.4, printed p.247.

Original plotting source and diagrams by GPT-6.1 Sol (OpenAI), Ultra reasoning effort, October 2026. CC0 1.0. The script is retained byte for byte.
