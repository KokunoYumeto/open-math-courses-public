"""Original CC0 diagrams of exact W1-W8; sampling is not the proof."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OWNED = Path(__file__).resolve().parent
OUT = OWNED/'figures'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,
                     'axes.spines.right':False,'figure.facecolor':'white','savefig.facecolor':'white'})

def transition(z):
    z=np.asarray(z,dtype=float)
    f=np.zeros_like(z);fp=np.zeros_like(z);fpp=np.zeros_like(z)
    f[z>=.75]=1
    use=(z>.25)&(z<.75)
    a=z[use]-.25;b=.75-z[use]
    A=np.exp(-1/a);B=np.exp(-1/b);C=A+B
    Ap=A/a**2;Bp=-B/b**2
    App=A*(a**-4-2*a**-3);Bpp=B*(b**-4-2*b**-3)
    Cp=Ap+Bp;Cpp=App+Bpp
    f[use]=A/C
    fp[use]=(Ap*C-A*Cp)/C**2
    fpp[use]=App/C-A*Cpp/C**2-2*Ap*Cp/C**2+2*A*Cp**2/C**3
    return f,fp,fpp

def block(s,L=2.):
    s=np.asarray(s);ell=-4*L;ellp=-6*L;m=-8*L;n=-2*L;omega=L**3
    C=np.empty_like(s);A=np.empty_like(s);b1=np.zeros_like(s);b0=np.zeros_like(s)
    for j in range(5):
        mask=(s>=j)&((s<j+1) if j<4 else (s<=5));q=s[mask]
        if j in (0,4):
            f,fp,fpp=transition(q if j==0 else 5-q)
            c=ell if j==0 else ellp
            C[mask]=np.exp(c);A[mask]=np.exp(m)*f
            b0[mask]=np.exp(m-c)*abs(fpp)
            b1[mask]=b0[mask]/omega
        elif j in (1,3):
            f,fp,fpp=transition(q-1 if j==1 else 4-q)
            g=m+(n-m)*f;Q=(n-m)*fpp+((n-m)*fp)**2
            C[mask]=np.exp(ell if j==1 else ellp);A[mask]=np.exp(g)
            b1[mask]=abs(Q)/omega
        else:
            f,fp,fpp=transition(q-2);g=ell+(ellp-ell)*f
            Q=(ellp-ell)*fpp+((ellp-ell)*fp)**2
            C[mask]=np.exp(g);A[mask]=np.exp(n)
            b1[mask]=np.exp(g-n)*abs(Q)/omega
    return C,A,b1,b0

def geometry():
    fig,(ax,bx)=plt.subplots(1,2,figsize=(12,5.3),gridspec_kw={'width_ratios':[1.12,1]})
    xs=np.linspace(-1,1,800);ys=.25*xs**2
    ax.fill_between(xs,-.22,0,color='#DDEBF6',label=r'actual $F=\{t\leq0\}\cap X$')
    ax.plot(xs,ys,color='#C65A24',lw=2.6,label=r'$\psi=0: t=x^2/4$')
    ax.axhline(0,color='#537789',lw=.8);ax.scatter([0],[0],s=64,c='#A82E38',zorder=5)
    ax.annotate('entire contact K = {(0,0)}',xy=(0,0),xytext=(-.9,.13),
                arrowprops={'arrowstyle':'->','color':'#A82E38'},color='#A82E38')
    ax.text(.06,-.13,r'$u\in C^\infty\cap H^1_{\rm loc}$'+'\nnonzero in every neighborhood of 0',fontsize=10)
    ax.set(xlim=(-1,1),ylim=(-.22,.245),xlabel='x',ylabel='t',title='Fixed surface and full support (W12-W15)')
    ax.legend(loc='lower left',fontsize=9)
    bx.axhline(0,color='#A82E38',lw=2.4,label=r'$p=H_p\psi=0:\ \tau=0$')
    bx.scatter([-.4,0,.4],[1,1,1],c='#C65A24',s=38,label=r'$d\psi=(1,-x/2)$, x = 0.8, 0, -0.8')
    bx.text(-1.1,-.49,r'$p=\tau^2,\quad H_p=2\tau\partial_t$'+'\n'+r'$H_p^2\psi=0$ on the whole nearby surface'+'\n'+r'fiber gradient = 0 on each constrained covector',fontsize=10)
    bx.text(-1.08,.59,r'$p(d\psi)=1$ at every base point',fontsize=11)
    bx.set(xlim=(-1.25,1.25),ylim=(-1.05,1.3),xlabel=r'$\xi$ (spatial covector)',ylabel=r'$\tau$ (normal covector)',title='Degenerate real quadratic fiber (W11,W14)')
    bx.text(-1.08,1.17,r'normal covectors: $d\psi=(1,-x/2)$',fontsize=10)
    bx.text(-1.08,.13,r'$p=H_p\psi=0:\ \tau=0$',fontsize=10,color='#A82E38')
    fig.suptitle('A compact-contact counterexample with real principal symbol',fontsize=16,y=.99)
    fig.text(.5,.015,'Exact delta=1/4. W1-W6 prove the solution; planar domains are plotted slices.\nLeray, Seminaire 1964-1965, pp.3-13; Hormander IV, Theorem28.4.3, printed247.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.075,1,.94));fig.savefig(OUT/'compact-contact-and-critical-fiber.png',dpi=180);plt.close(fig)

def mechanism():
    fig,axs=plt.subplots(3,1,figsize=(11.5,9.2),gridspec_kw={'height_ratios':[1.3,1,1]})
    s=np.linspace(0,5,2501);C,A,b1,b0=block(s,2)
    axs[0].plot(s,np.log(C),lw=2.2,label='log constant amplitude')
    logA=np.full_like(A,np.nan);use=A>0;logA[use]=np.log(A[use])
    axs[0].plot(s,logA,lw=2.2,label='log oscillator amplitude where positive')
    titles=['introduce oscillator','increase oscillator','decrease constant','decrease oscillator','remove oscillator']
    for j,title in enumerate(titles):
        for ax in axs[:2]:ax.axvline(j,color='#C9CED2',lw=.7)
        axs[0].text(j+.5,-3.5,title,ha='center',fontsize=9)
    axs[0].set(ylim=(-24,-2),xlim=(0,5),ylabel='log amplitude',title=r'Exact block L=2: $\ell=-8,\ m=-16,\ n=-4,\ \ell^{\prime}=-12,\ \omega=8$')
    axs[0].legend(loc='lower right',fontsize=9)
    axs[1].plot(s,np.where(b1>0,b1,np.nan),color='#226C87',lw=1.7,label=r'$|b_{1,L}(s,0)|$')
    axs[1].plot(s,np.where(b0>0,b0,np.nan),color='#AA663D',lw=1.7,label=r'$|b_{0,L}(s,0)|$')
    axs[1].set_yscale('log')
    axs[1].set(xlim=(0,5),ylim=(1e-6,1e4),xlabel='normalized s',ylabel='sampled magnitude (log scale)',title=r'Exact $v_{ss}=b_1v_x+b_0v$; coefficients vanish near every seam (W3)')
    axs[1].legend(fontsize=9)
    k=np.arange(1,161,dtype=float);L=2*(1.5)**(k-1)
    for h,c in [(0,'#226C87'),(2,'#AA663D')]:
        envelope=(h+2)*np.log10(5*k*k)-np.log10(L)
        axs[2].plot(k,envelope,color=c,lw=2,label=fr'$\log_{{10}}((5k^2)^{{{h+2}}}/L_k)$, time degree h={h}')
    axs[2].axhline(0,color='#C9CED2',lw=.8)
    axs[2].set(xlim=(1,160),xlabel='block k approaching r=T',ylabel='log10 envelope factor',title='Every fixed derivative: polynomial scale / exponential Lk tends to zero (W8)')
    axs[2].legend(fontsize=9)
    fig.suptitle('Five exact stages, then infinitely many shrinking blocks',fontsize=16,y=.995)
    fig.text(.5,.018,r'$L_k=2(3/2)^{k-1},\ \Delta r_k=k^{-2},\ s=5k^2(r-T_k),\ B_j=25k^4b_j$'+'\nSamples illustrate formulas. W4-W8 prove all derivative bounds; constants C(h,r) are not plotted.\nOscillator is exactly absent near the two outer endpoints. Leray, Sections1-2, pp.3-13.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.085,1,.96));fig.savefig(OUT/'five-band-flat-construction.png',dpi=180);plt.close(fig)

if __name__=='__main__':
    geometry();mechanism()
    (OUT/'figure-parameters.json').write_text(json.dumps({'delta':'1/4','L_sample':2,'ell':-8,'ell_prime':-12,'m':-16,'n':-4,'omega':8,'Lk':'2*(3/2)^(k-1)','block_width':'k^-2','source_locator':'Leray pp3-13; proof W1-W8','authoring_scope':'Original exact research diagrams; CC0','figures_are_proof':False},indent=2)+'\n',encoding='utf8')
