# Original figure sources and exact coordinate inputs

Both original diagrams and plotting sources are CC0 1.0, by GPT-6.1 Sol (OpenAI), Ultra, October 2026. Run each source with Python, matplotlib and numpy; one-sided-contact.py also uses Pillow. Each source writes its PNG beside itself. The second additionally writes its deterministic vector SVG alternate. Its outlined labels can be changed in the plotting source. Neither source imports a book image or prescribes a nonzero PDE solution.

The exact reproduction run used python 3.13.9, matplotlib 3.10.9, numpy 2.4.4, Pillow 12.2.0. These versions reproduce the received PNG and SVG bytes; other plotting-library versions may change rendering bytes. The unchanged Lorentzian PNG contains the historical metadata description “Private receiving geometry, G12--G36”; it names its original drafting context and carries no machine path.

## Negative-side quadratic geometry

Input: n=3, p=xi1²−xi2²+xi3², A=2, Phi=x1[1−A(x2²+x3²)]. The left section is x3=0, −0.31≤x2≤0.31 and −0.15≤x1≤0.03. Negative levels h=0.03,0.06,0.09 are exact x1=−h/(1−Ax2²). Arrows give directions of V=(w,2Ax1x2,−2Ax1x3)/c, w=1−A|x′|² and c=w²−4A²x1²x2²+4A²x1²x3²; V Phi=1. The right panel uses −0.2≤t≤0.2, h=0,0.05,0.1 and the exact characteristic curve x(t)=(−h,−2t,2t), xi=(0,1,1). The indicated original surface is weak, with Hp²Phi=0 at h=0. The plotted box is a specified example, not a universal coefficient neighborhood. Source: [negative-side-geometry.py](negative-side-geometry.py).

**Figure G.1.** Exact example `p=xi1^2-xi2^2+xi3^2`, `Phi=x1[1-A(x2^2+x3^2)]`, A=2. The left section x3=0 shows the original oriented zero surface, exact negative Phi levels and directions of the normalized polarized field V in G25. The right panel shows the exact characteristic Hamilton curves with covector `(0,1,1)` and initial point `(-h,0,0)`: `Phi(x(t))=-h+8Ah t^2` and `(Hp^2 Phi)(x(0),xi)=16Ah`, evaluated at Hamilton time t=0 and initial base point x(0)=(-h,0,0). The surface curve h=0 remains flat. These formulas illustrate the proved negative-side mechanism without claiming strictness on the original surface or asserting that the pictured box is the delta selected for an arbitrary variable symbol. Reproducible source: [negative-side-geometry.py](negative-side-geometry.py); exact proof locators G12--G36; human source: Hörmander IV, Lemma 28.4.2 and the adapted-coordinate paragraph, printed pp. 246--247.

The general findings are the exact negative-side bound G22, the noncharacteristic estimate G23, and the cross-term-free coordinate form G31. The positive side is preserved because y1=Phi and Phi=x1w with w>0; neither division by a negative symbol coefficient nor normalization of the polarized flow reverses that side. The tangent Hamilton condition uses the minus sign in G13, including the complete mixed term in G14.

A useful exact example is the constant Lorentzian quadratic p=xi1^2-xi2^2+xi3^2, r=xi2^2-xi3^2. Its fiber gradient (2xi1,-2xi2,2xi3) is nonzero at every nonzero real covector and r1=0, so the surface test is weak, not strict. For A>0, Phi=x1[1-A(x2^2+x3^2)]. At the point (-h,0,0), xi=(0,1,1) is characteristic and tangent to Phi; its Hamilton curve is x(t)=(-h,-2t,2t), with fixed covector. Exactly Phi(x(t))=-h+8Ah t^2 and (Hp^2Phi)(x(0),xi)=16Ah, evaluated at Hamilton time t=0 and x(0)=(-h,0,0), not at the base origin unless h=0. At h=0 the entire curve lies in the original surface and Phi=0. The negative-side improvement is visible without inventing strict convexity on the surface.

The exact normalized polarized field is V=(w,2Ax1x2,-2Ax1x3)/c, with c=p(dPhi)=w^2-4A^2x1^2x2^2+4A^2x1^2x3^2. It satisfies VPhi=1 where c is nonzero. In the x3=0 section, the y1=-h level is x1=-h/[1-Ax2^2]. The plotted arrow directions use this exact V, scaled only for visual legibility, and the legend says directions rather than vector lengths. Their tangential drift is why keeping the original x' as y' would not generally eliminate mixed principal terms.

## One-sided kernel, complete contact envelope and scalar gap

Input: h>0, j from WX9, support rectangle [−5/2,−3/2]×[−1/4,1/4] inside B((−2,0),1); actual convolution displacement is (−3h,−h), with sharper closed normal bound [−5h/2,−3h/2]. The teaching envelope F*, full contact envelope K*, constructed smooth cutoff chi and target N are exactly WX12–WX13. The applied commutator bound is t≤−1/8, target t>−1/16. phi(t)=t+t²/2, a=−15/128, b=−31/512, b−a=29/512, and squared-norm decay is exp(−29tau/256). These teaching objects do not specify an actual solution support or the cutoff for a general theorem solution. The plotting source asserts the exact fractional gap and containment-radius inequality. Complete normalization, displacement, derivative-support and envelope arguments are the accompanying solved exercises. Source: [one-sided-contact.py](one-sided-contact.py); [vector SVG](one-sided-contact.svg).

**Figure WX.1.** Panel A uses the exact nonnegative normalized kernel of (WX9). Its compact support rectangle lies strictly inside the unit ball centered at \((-2,0)\), so every normal displacement belongs to \((-3h,-h)\); the sharper displacement bound is \([-5h/2,-3h/2]\). Convolution adds the displacement to an input support point, \(z=y+q\), and hence carries the nonpositive input side into \(z_1\le-3h/2\). Panel B uses the explicit coordinate exercise envelope \(F_*\), the full compact contact envelope \(K_*\), and the independently constructed exercise cutoff \(\chi\) in (WX12)–(WX13). It shows a bound for the applied commutator support below \(t=-1/8\), and the smaller target neighborhood \(N\) where \(\chi=1\). Panel C graphs the scalar weight \(\phi(t)=t+t^2/2\): its error level \(a=-15/128\) and target level \(b=-31/512\) have the exact positive gap \(29/512\). This produces the exponential factor \(e^{-29\tau/256}\) in (WX14). The figure does not prescribe a nonzero PDE solution, its actual support, or the cutoff chosen for an unspecified solution in the general theorem. Exact proof locators: learner (WX9)–(WX14) and receiving proof (W8)–(W16). Human source: Lars Hörmander, *The Analysis of Linear Partial Differential Operators IV*, Springer, 2009 reprint, Section 28.4, printed pp. 243–247, especially Theorem 28.4.3 on p. 247. Reproducible original source: [one-sided-contact.py](one-sided-contact.py); its exact assertions check the fractional gap and kernel-radius containment, while the complete normalization, displacement, graph and envelope arguments are the six solutions below. Original figure and notes by GPT-6.1 Sol (OpenAI), Ultra, October 2026; CC0 1.0 public-domain dedication.

### Coordinates and exact objects


In Panel A the horizontal variable is the **normal** displacement \(q_1/h\), while the vertical variable is the **tangential** displacement \(q_2/h\). This is kernel coordinate space; it is not base space or phase space. The allowed open ball is \(B((-2,0),1)\). Define

\[
 \beta(s)=\begin{cases}e^{-1/(1-s^2)},&|s|<1,\\0,&|s|\ge1,\end{cases}
 \quad I=\int_{-1}^1\beta(s)\,ds>0,
 \quad j(q)=\frac8{I^2}\beta(2(q_1+2))\beta(4q_2).
\]

Both factors are smooth and flat at their endpoints. Their integrals are \(I/2\) and \(I/4\), so \(\int j=1\). The closed support rectangle is \([-5/2,-3/2]\times[-1/4,1/4]\). Its farthest corner from \((-2,0)\) has squared distance \(5/16<1\), giving strict compact containment in the ball. For \(j_h(q)=h^{-2}j(q/h)\), the displayed normal interval is the sharp support bound, and the dashed lines at \(-3\) and \(-1\) mark the larger allowed open interval. Kernel positivity is convenient for this model; compact support and integral one are the graph proof's essential conditions. Symmetry is not required.

In Panels B and C, \(t\) is the normal **base** coordinate and \(x\) the tangential base coordinate. Panel B has axes \((x,t)\), so its displayed contact segment is \([-1/4,1/4]\times\{0\}\), while mathematical ordered pairs in the exercises use \((t,x)\). Axis scaling in Panel B is chosen for legibility and does not assert metric distances. The full chosen chart is

\[
 Z=(-1/2,1/2)\times(-1,1),\qquad
 F_* = \{(t,x)\in Z:t\le0,\ |x|\le1/4\ \text{or}\ t\le-1/8\}.
\]

The picture shows only the window \(-0.28\le t\le0.28\), \(-0.85\le x\le0.85\), strictly inside \(Z\). Gray shading denotes the permitted **envelope** \(F_*\), never an actual solution support. Given the exercise's support bound \(F\subset F_*\), the entire contact \(K=F\cap\{t=0\}\) lies in the compact segment \(K_*\). Thus the figure draws \(K_*\), labels \(K\subset K_*\), and does not invent which contact points belong to \(F\).

The explicit exercise cutoff is defined using the smooth increasing transition \(\Theta\) from (WX13):

\[
 \chi(t,x)=\Theta(2-8|t|)\Theta(3-4|x|),\quad
 O=(-1/8,1/8)\times(-1/2,1/2),\quad
 N=(-1/16,1/16)\times(-1/4,1/4).
\]

This \(\chi\) is one on \(O\), hence on \(N\), and has support in \([-1/4,1/4]\times[-3/4,3/4]\Subset Z\). It is a constructed example suitable for every contact subset of this **specified** envelope; it is not the general theorem's unknown solution-dependent cutoff. The outer dashed rectangle is a support **bound**, and the green rectangle is the unit-cutoff region. The blue rectangle is the target neighborhood. In particular the cutoff covers all of \(K_*\), rather than only the base point.

The derivative supports of order one or two lie in the union of the normal transition strips \(1/8\le|t|\le1/4\) and tangential transition strips \(1/2\le|x|\le3/4\), within the support rectangle. Intersecting that union with \(F_*\) lies in the red hatched **error envelope**

\[
 E_*=[-1/4,-1/8]\times[-3/4,3/4].
\]

The actual applied commutator can have smaller or empty support. Its first-order lower contribution is \(-ie\sum_jb_j(ez)\partial_j\chi\,u\); no bounded lower coefficient is differentiated. If the applied commutator vanishes, the weighted estimate immediately forces \(\chi u=0\), without taking a maximum over an empty error set. The diagram shows only the support bound used for the nonzero branch.

## Weight mechanism and limits

Panel C graphs a scalar function of \(t\); it depicts neither a bicharacteristic nor solution amplitudes. On \([-1/2,0]\), \(\phi'(t)=1+t\ge1/2>0\). The error envelope gives \(\phi\le a=\phi(-1/8)=-15/128\), while \(N\cap\{t\le0\}\) gives \(\phi\ge b=\phi(-1/16)=-31/512\). Hence

\[
 b-a=\frac{29}{512}>0,\qquad
 \|u\|_{L^2(N)}^2\le4C_0A^2\tau^{-3}e^{-29\tau/256}\longrightarrow0,
 \quad A=\|[P_e,\chi]u\|_2.
\]

The chart, principal coefficient bounds, geometric constants, and spatial scale \(e\) are fixed first. At each fixed \(\tau\), one-sided graph smoothing passes \(h\to0\). Only afterwards is \(\tau\to\infty\) taken. The figure's strict **scalar level gap** does not assert strict pseudoconvexity on the original surface: the theorem uses weak convexity and retains the surrounding strong fiber hypothesis. The isolated printed final theorem omits that standing assumption; no theorem without it is certified here. The conclusion remains vanishing on the smaller neighborhood \(N\), with no assertion of vanishing on all of \(Z\).


Human source: Lars Hörmander, The Analysis of Linear Partial Differential Operators IV, Springer, 2009 reprint, Section28.4, printed242–247. Exact proof locators G12–G36 and W8–W16, exercise locators WX9–WX14. Complete arguments and all six solutions accompany these diagrams in L058.
