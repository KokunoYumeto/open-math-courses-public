from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json
OUT=Path(__file__).resolve().parent
W,H=2360,1780
im=Image.new("RGB",(W,H),"white"); d=ImageDraw.Draw(im)
font=lambda n:ImageFont.truetype("C:/Windows/Fonts/arial.ttf",n)
f=font(30); small=font(25); title=font(47); med=font(35)
blue="#245e87"; green="#287d68"; red="#ba4d2b"; ink="#16222c"
def txt(pos,s,ft=f,fill=ink): d.text(pos,s,font=ft,fill=fill)
def box(rect,fill="#edf4f8",outline=blue): d.rounded_rectangle(rect,radius=15,fill=fill,outline=outline,width=3)
txt((45,25),"The higher-dimensional mixed Lipschitz proof: roots, operators and the physical tail",title)
txt((48,90),"D = -i partial; q(y) = 1/10 + min(|x_1|,1)/10; b(y) = 1 + min(|t|,1)",f)
txt((48,135),"p = sigma [(sigma - q xi_1)^2 + b^2 (xi_1^2 + xi_2^2)]; real characteristic hypersurface sigma = 0",f)
txt((48,180),"At xi != 0: roots 0, q xi_1 +/- i b |xi| are simple; at xi = 0 the repeated root gives the excluded zero covector.",small)
box((45,235,1180,730))
box((1210,235,2310,730))
txt((70,252),"An exact finite angular partition",med,blue)
txt((70,300),"theta_k = k pi/4, k=0,...,7; angular radius pi/3",small)
txt((70,335),"h_k = exp(-1/[1-(angle distance/(pi/3))^2]) inside support, 0 outside",small)
txt((70,370),"psi_k = h_k / sqrt(sum h_l^2); sum psi_k^2 = 1 exactly (2.2) in Simple-root uniqueness",small)
colors=["#255c8d","#c33f45","#238365","#8059a5","#cb8126","#31999b","#994a81","#5c6f32"]
x0,y0,x1,y1=105,435,1125,660
d.line((x0,y0,x0,y1,x1,y1),fill=ink,width=2)
def weights(t):
    hs=[]
    for k in range(8):
        a=abs((t-k*math.pi/4+math.pi)%(2*math.pi)-math.pi)
        hs.append(math.exp(-1/(1-(a/(math.pi/3))**2)) if a<math.pi/3 else 0.0)
    den=sum(v*v for v in hs)
    return [v*v/den for v in hs]
max_error=0.0
for k in range(8):
    points=[]
    for j in range(801):
        t=2*math.pi*j/800; w=weights(t)
        max_error=max(max_error,abs(sum(w)-1))
        points.append((x0+(x1-x0)*j/800,y1-(y1-y0)*w[k]))
    d.line(points,fill=colors[k],width=3)
txt((68,420),"1",small);txt((70,638),"0",small)
txt((x0,677),"0",small);txt((x0+(x1-x0)/2-10,677),"pi",small);txt((x1-28,677),"2pi",small)
txt((1228,252),"Exact homogeneous roots at the reference base",med,green)
txt((1230,300),"q_0 = 1/10, b_0 = 1, |xi| = 1; omega = (cos theta, sin theta)",small)
txt((1230,340),"c_0 = 0; c_+ = (cos theta)/10 + i; c_- = (cos theta)/10 - i",small)
cx,cy=1780,525; sx,sy=2350,95
d.line((1350,cy,2205,cy),fill=ink,width=2)
d.line((cx,398,cx,685),fill=ink,width=2)
txt((2180,cy+35),"Re c",small);txt((cx+20,393),"Im c",small)
for val,col in [(1,green),(-1,red)]:
    d.line((cx-sx*.1,cy-sy*val,cx+sx*.1,cy-sy*val),fill=col,width=8)
    for j in range(0,361,15):
        re=.1*math.cos(2*math.pi*j/360)
        xx,yy=cx+sx*re,cy-sy*val
        d.ellipse((xx-3,yy-3,xx+3,yy+3),fill=col)
d.ellipse((cx-6,cy-6,cx+6,cy+6),fill=blue)
txt((cx+18,cy-27),"0",small)
txt((cx-sx*.1-40,cy+15),"-1/10",small);txt((cx+sx*.1-30,cy+15),"1/10",small)
txt((cx+265,cy-sy-18),"+i",small,green);txt((cx+265,cy+sy-18),"-i",small,red)
txt((1230,696),"Imaginary gap >= 1; pair separation >= 1. Nonlinear |xi| dependence.",small)
box((45,760,2310,1090))
txt((75,780),"The actual frequency-dependent operator reconstruction",med,blue)
txt((75,835),"U_j = D_t^j Lambda^(m-1-j) u,  Lambda = <D_x>;  D_t U = Op(C) U + e_m P u",f)
txt((75,880),"S_j = (1, nu_j, ..., nu_j^(m-1))^T;  V_l = Op(S_l)^(-1) chi_l(D_x) U",f)
txt((75,925),"The inverse is the genuine bounded operator inverse on L2, H1 and H^-1 (Angular calculus, Section 11).",f)
txt((75,970),"Rough products + actual adjoints + one weak time derivative give a bounded order-zero remainder (8.4).",f)
txt((75,1015),"A low-frequency block and every angular commutator remain; the fixed scale and cutoff are independent of tau.",f)
box((45,1120,900,1570),fill="#f0f6f3",outline=green)
txt((70,1138),"The nonlocal physical tail is proved",med,green)
cx,cy,scale=370,1370,55
d.ellipse((cx-3*scale,cy-3*scale,cx+3*scale,cy+3*scale),outline=green,width=3)
d.ellipse((cx-scale,cy-scale,cx+scale,cy+scale),fill="#c4dcea",outline=blue,width=3)
txt((cx-42,cy-20),"|z| < 1",small,blue)
txt((170,1530),"root/polynomial symbols agree for |x| <= 3",small,green)
xout=cx+4*scale
d.ellipse((xout-7,cy-7,xout+7,cy+7),fill=red)
d.line((cx+scale,cy,xout,cy),fill=red,width=3)
txt((xout+18,cy-38),"|x| > 3",small,red)
txt((590,1420),"|x-z| >= 2",small,red)
txt((565,1460),"|K_j| <= C_N |x-z|^-N",small)
txt((565,1500),"N > d+m+2 (9.4)",small)
box((930,1120,2310,1570))
txt((960,1140),"The full norm ladder, with the original odd powers",med,blue)
txt((960,1200),"tau ||W U||^2 <= H_0 ||W P u||^2",f)
txt((960,1250),"Scalar time integration has constant 4 and supplies every lower derivative:",f)
txt((960,1300),"sum_(|alpha|<m) tau^[2(m-|alpha|)-1] ||W D^alpha u||^2",med)
txt((960,1350),"<= [(4^m-1)/3] H_0 ||W P u||^2  (11.2)",med)
txt((960,1410),"For this order-three, dimension-three model:",f)
txt((960,1450),"tau^5 ||Wu||^2 + tau^3 sum_(|alpha|=1) ||W D^alpha u||^2",f)
txt((960,1493),"+ tau sum_(|alpha|=2) ||W D^alpha u||^2 <= C ||W P u||^2",f)
txt((48,1600),"Proofs: Angular calculus, Sections 1-12; Simple-root uniqueness, Sections 1-14.",small)
txt((48,1640),"References: A.P. Calderon, Commutators (ICM1978); L. Hormander, The Analysis of Linear Partial Differential Operators IV.",small)
txt((48,1680),"The partition curves and reference roots are exact objects; tail arrows are a schematic of the proved separated-kernel bound.",small)
txt((48,1720),"Original mathematical diagram and reproducible source, CC0. No solution is numerically simulated.",small)
im.save(OUT/"mixed-high-dimensional-mechanism053.png")
(OUT/"figure-check.json").write_text(json.dumps({
    "partition_formula":"h_k/sqrt(sum h_l^2), theta_k=k*pi/4, support radius pi/3",
    "partition_800_sample_max_squared_sum_error":max_error,
    "sample_is_not_partition_proof":"Exact normalization is proved in Simple-root uniqueness (2.2).",
    "model":"sigma[(sigma-q xi_1)^2+b^2(xi_1^2+xi_2^2)]",
    "reference_values":{"q":"1/10","b":"1","transverse_dimension":2,"order":3},
    "coordinate_and_tail_labels":"input |z|<1, matching |x|<=3, tail output |x|>3, distance>=2",
    "proof_locators":["Simple-root uniqueness (2.2),(6.1)-(11.2)","Angular calculus (7.1)-(11.1)"],
    "render_pixels":[W,H]
},indent=2)+"\n",encoding="utf-8")
print(json.dumps({"image":str(OUT/"mixed-high-dimensional-mechanism053.png"),"max_partition_sample_error":max_error}))
