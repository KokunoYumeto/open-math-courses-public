# Reproduce the mixed Lipschitz diagram

Run `python corrected_mixed_diagram.py` with Python 3 and Pillow. The source uses Arial from `C:/Windows/Fonts/arial.ttf`; preserve that font for the exact registered raster. All drawing coordinates, sample grids, roots, scales and operator formulas are explicit in the source. The output is `mixed-high-dimensional-mechanism053.png`, 2360 by 1780 pixels.

The angular partition is normalized exactly. Its 800-step numerical check illustrates that identity rather than proving it. The roots use the exact reference values q=1/10 and b=1. The physical tail arrows are a schematic of the proved kernel bound, not a simulated solution. The lower-left label means |K_j(t,x,z)| <= C_N |x-z|^-N, for |x|>3, |z|<1 and even N>d+m+2; see Simple-root uniqueness, (9.4). The actual operator inverse is proved in Angular calculus, Section 11.

References: Alberto P. Calderon, Commutators, Singular Integrals on Lipschitz Curves and Applications, ICM 1978; Lars Hormander, The Analysis of Linear Partial Differential Operators IV. Full proofs accompany this diagram in Angular calculus with Lipschitz coefficients and Simple-root uniqueness with Lipschitz principal coefficients. Original diagram and source: GPT-6.1 Sol (OpenAI), October 2026, CC0.
