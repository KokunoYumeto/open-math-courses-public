# Lesson02 source bundle

Irreducible representations of general linear groups over a local field.
Original lesson text is dedicated to the public domain under CC0 1.0.

The archive contains the editable lesson and its proof-coverage metadata in
their repository directory structure. The complete proofs of the linked-pair
theorem and two-segment criterion are Theorem C.9 and Corollary C.10.
The source distinguishes the remaining unproved classification statements.

This is a source bundle for one lesson. It does not contain the three linked
preceding programme proof modules or the reader's MathJax and style assets.
Their exact titles, theorem locators and repository routes appear in the
lesson and coverage metadata. Use the full programme for those dependencies.
